# UrekaTools

UrekaTools installs two integrated Unity 6 HDRP tools:

- **EpicImport** normalizes FBX/OBJ imports, extracts textures and materials, builds ORM maps, assigns EpicShade, and generates identity-root prefabs.
- **EpicShade** is a stylized HDRP material shader with packed/separate PBR maps, rim lighting, material-controlled outlines, layering, and plant sway.

## Start here

Open **UrekaTools > EpicImport > Open Importer**. EpicImport is the primary window because EpicShade is normally selected from a material's Shader menu.

EpicShade shaders appear under:

- `EpicShade/EpicShade HDRP`
- `EpicShade/EpicShade HDRP Transparent`

## EpicImport workflow

1. Open the EpicImport window.
2. Click **Import Model...**, or place models under the watched folder.
3. EpicImport can extract embedded textures/materials, copy image sidecars from the source folder, convert materials to EpicShade, pack AO/roughness/metallic into ORM, and generate a clean prefab with position 0, rotation 0, and scale 1.

Textures are isolated under `Textures/<ModelName>` so maps from other imported models cannot be selected accidentally. To repair an older import, select its model asset and choose **UrekaTools > EpicImport > Rebuild Selected Model Materials**.

For an exact 3ds Max pivot, export a helper/dummy named `__PIVOT__` and use Marker pivot mode. OBJ does not contain pivot or hierarchy metadata.

FBX and OBJ use Unity's built-in model importer. GLB/glTF files require a compatible glTF importer package; EpicImport detects the missing importer and explains the requirement instead of silently treating the file as imported.

## EpicShade PBR maps

Packed **Surface ORM Map** channels are R = occlusion, G = roughness, B = metallic. EpicShade matches Autodesk Interactive's PBR math: occlusion and metallic are used directly, while roughness becomes HDRP smoothness with `1 - sqrt(roughness)`. Import data maps with sRGB disabled. Separate metallic and roughness maps use their red channel and override the corresponding packed ORM channel.

Disable **Build Packed ORM** in EpicImport to assign separate metallic and roughness textures directly. EpicImport configures these data textures as linear automatically.

EpicShade outlines use an event-driven renderer cache. Scene and hierarchy changes refresh it automatically. Add `EpicShadeOutlineTarget` to dynamically spawned runtime objects that use an outlined EpicShade material so they register immediately without periodic scene scans.

The original serialized shader property identifiers are retained internally so existing UEisBetter materials and scenes keep their values after upgrading to UrekaTools.

## Requirements

- Unity 6 (`6000.0` or newer)
- HDRP 17 or newer

## Installation

In Package Manager choose **+ > Install package from tarball** and select `com.pedro.urekatools-1.2.4.tgz`, or choose **Install package from disk** and select this package's `package.json`.

## Distribution restriction

EpicShade contains derivative copies of proprietary OmniShade assets. Keep distribution within an appropriately licensed studio/team. Do not publish, sell, sublicense, or distribute it outside the licensed organization without permission covering that distribution.
