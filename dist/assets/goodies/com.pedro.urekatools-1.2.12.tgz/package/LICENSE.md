# License

Copyright (c) TGC. All rights reserved.

Internal studio use only. Third-party components remain subject to their respective licenses.
