# Changelog

## 1.2.12 - 2026-10-16

- Fixed separate metallic and roughness subgraph inputs resolving to Unity's default white texture instead of the assigned material textures.
- Completed the Shader Graph texture property GUID bindings in both opaque and transparent EpicShade graphs.
- Verified `*_m` is sampled from red and `*_r` from red on `sk_male_farmerA`, matching the equivalent packed ORM channels.

## 1.2.11 - 2026-10-16

- Matched Autodesk Interactive's PBR channel math end to end: metallic is direct, roughness converts with `smoothness = 1 - sqrt(roughness)`, and ambient occlusion is direct.
- Removed EpicShade's non-Autodesk AO power adjustment from the active shader path and hid its obsolete material control.

## 1.2.10 - 2026-10-16

- Matched Autodesk Interactive's perceptual roughness conversion: `smoothness = 1 - sqrt(roughness)`.
- Applied the same conversion to separate roughness textures and packed ORM green channels.
- Corrected generated ORM fallback values when no roughness texture is available.

## 1.2.9 - 2026-10-16

- Fixed separate metallic textures being assigned but ignored after HDRP rebuilt the material keyword set.
- Persisted the Surface ORM, separate metallic, and separate roughness modes as hidden material properties.
- Restores EpicShade PBR keywords from their serialized modes after validation, shader reimport, play mode changes, and editor restarts.
- Updated EpicImport to initialize both the persistent PBR modes and their matching shader keywords.

## 1.2.8 - 2026-10-16

- Restored the proven 1.2.3 EpicShade shader graphs and material Inspector behavior.
- Removed the unrelated custom material and FBX thumbnail renderers added in 1.2.6-1.2.7.
- Restored lossless generated ORM import so packed roughness/metallic shading matches the separate source maps.
- Kept generated ORM maps linear and capped at 2048 pixels, limiting an uncompressed map to 16 MB instead of 64 MB at 4K.
- Verified roughness conversion is applied exactly once: `HDRP smoothness = 1 - ORM.g`.

## 1.2.7 - 2026-10-16

- Fixed the EpicShade material-preview fallback corrupting Unity's Inspector layout during non-repaint GUI events.
- Added a deferred, cached HDRP-safe 3D thumbnail renderer for EpicImport models whose normal FBX preview appears white or magenta.
- Limited generated model-preview memory to 64 small thumbnails and releases the cache during assembly reload.

## 1.2.6 - 2026-10-16

- Added a deterministic albedo preview fallback for EpicShade materials when Unity's isolated HDRP preview renderer drops Shader Graph texture bindings and renders a white sphere.

## 1.2.5 - 2026-10-16

- Persisted separate metallic and roughness override states so HDRP validation cannot re-enable stale overrides over ORM.
- Mirrored EpicShade's base texture into HDRP preview aliases so imported material thumbnails retain their albedo preview.

## 1.2.4 - 2026-10-16

- Fixed packed ORM generation reusing a similarly named texture from a different model.
- Isolated extracted and generated textures under `Textures/<ModelName>`.
- Added **UrekaTools > EpicImport > Rebuild Selected Model Materials** for repairing existing imports.
- Ensured metallic, roughness, occlusion, and generated ORM textures are imported as linear data.
- Uses high-quality GPU compression for mask maps, avoiding 64 MB 4K uploads that could turn Editor previews white.
- Persisted the Surface ORM toggle as a material property so HDRP keyword validation cannot silently disable it.

## 1.2.3 - 2026-10-16

- Fixed Unity 6000.0 editor API compatibility in the EpicShade material inspector.
- Fixed the package exporter to use the Package Manager API available across Unity 6000 releases.

## 1.2.2 - 2026-10-16

- Fixed the outline renderer search failing to compile in Unity 6000.0.
- Switched to the cross-version `FindObjectsByType` overload supported by Unity 6000.0 through 6000.4.

## 1.2.1 - 2026-10-16

- Changed the package identifier from `com.tgc.urekatools` to `com.pedro.urekatools`.
- Changed assembly ownership from `TGC.UrekaTools` to `Pedro.UrekaTools`.
- Updated the package author to Pedro.

## 1.2.0 - 2026-10-16

- Renamed the combined package and top-level Unity menu from UnrealTools to UrekaTools.
- Changed the package identifier to `com.tgc.urekatools` and updated package-local shader paths.
- Preserved all shader asset GUIDs and legacy serialized property identifiers for existing materials.

## 1.1.0 - 2026-10-15

- Replaced the one-second outline renderer search with event-driven cache invalidation.
- Made the full-screen outline mask lazy and release it when no outlined renderer exists.
- Added `EpicShadeOutlineTarget` for dynamically spawned outlined renderers.
- Removed automatic project-wide Shader Graph variant-limit changes.
- Removed automatic reprocessing of the entire watched folder after installation/reload.
- Added optional sidecar texture copying during manual model import.
- Added separate metallic and roughness texture assignment when ORM packing is disabled.
- Added texture discovery beside the model and in nested texture folders.

## 1.0.0 - 2026-10-15

- Combined EpicImport and EpicShade into the UrekaTools package (originally released as UnrealTools).
- Renamed the public shader menu from UEisBetter to EpicShade.
- Renamed Clean Model Importer to EpicImport.
- Added the top-level tools menu with EpicImport first.
- Preserved shader asset GUIDs and serialized property identifiers for project migration.
