#if UNITY_PIPELINE_HDRP
using UnityEditor;

[InitializeOnLoad]
static class UEisBetterOutlineEditorBootstrap
{
	static UEisBetterOutlineEditorBootstrap()
	{
		EditorApplication.delayCall += UEisBetterOutlineBootstrap.EnsureRegistered;
		EditorApplication.hierarchyChanged += UEisBetterOutlinePass.InvalidateRendererCache;
		AssemblyReloadEvents.beforeAssemblyReload += BeforeAssemblyReload;
	}

	static void BeforeAssemblyReload()
	{
		EditorApplication.hierarchyChanged -= UEisBetterOutlinePass.InvalidateRendererCache;
		UEisBetterOutlineBootstrap.Unregister();
	}
}
#endif
