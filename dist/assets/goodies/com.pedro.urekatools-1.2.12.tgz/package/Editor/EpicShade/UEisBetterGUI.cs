//------------------------------------
//              UEisBetter
// Local derivative of OmniShade PBR for licensed project use.
// Original work Copyright© 2025 OmniShade.
//------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
#if UNITY_PIPELINE_HDRP
using UnityEditor.Rendering.HighDefinition;
#endif

/**
 * This class manages the GUI for the shader, automatically enabling/disabling keywords when values change.
 **/
#if UNITY_2021_1_OR_NEWER && UNITY_PIPELINE_HDRP
public class UEisBetterGUI : LightingShaderGraphGUI
#else
public class UEisBetterGUI : ShaderGUI
#endif
{
	const string RimSharpnessProperty = "Vector1_9350150";
	const float MigratedRimSharpness = 0.5f;
	const float MinimumRimSharpness = 0.05f;
	const float MaximumRimSharpness = 10f;
	const string SurfaceOrmProperty = "_ORMMap";
	const string SurfaceOrmToggleProperty = "_UseSurfaceORM";
	const string MetallicProperty = "_Metallic";
	const string SmoothnessProperty = "_Smoothness";
	const string MetallicTextureProperty = "_MetallicMap";
	const string RoughnessTextureProperty = "_RoughnessMap";
	const string MetallicTextureToggleProperty = "_UseMetallicTexture";
	const string RoughnessTextureToggleProperty = "_UseRoughnessTexture";
	const string MetallicMapKeyword = "METALLIC_MAP_ON";
	const string OcclusionMapKeyword = "OCCLUSION_MAP_ON";
	const string MetallicTextureKeyword = "METALLIC_TEXTURE_ON";
	const string RoughnessTextureKeyword = "ROUGHNESS_TEXTURE_ON";
	const string OutlineEnabledProperty = "_UEisBetterOutlineEnabled";

	// Shader keywords which are automatically enabled/disabled based on usage
	static List<(string keyword, string name, PropertyType type, Vector4 defaultValue)> props =
		new List<(string keyword, string name, PropertyType type, Vector4 defaultValue)>(){
		("NORMAL_MAP_ON", "_BumpMap", PropertyType.Texture, Vector4.one),
		("NORMAL_MAP2_ON", "_BumpMap2", PropertyType.Texture, Vector4.one),
		("EMISSION_MAP_ON", "_EmissionMap", PropertyType.Texture, Vector4.one),
		("REFLECTION_ON", "_ReflectionMap", PropertyType.Texture, Vector4.one),
		("DETAIL_MAP_ON", "_DetailMap", PropertyType.Texture, Vector4.one),
		("LAYER1_ON", "_Layer1", PropertyType.Texture, Vector4.one),
		("LAYER2_ON", "_Layer2", PropertyType.Texture, Vector4.one),
		("LAYER3_ON", "_Layer3", PropertyType.Texture, Vector4.one),
		("HEIGHT_COLORS_TEX_ON", "_HeightColorsTex", PropertyType.Texture, Vector4.one),
		("SHADOW_OVERLAY_ON", "_ShadowOverlayTex", PropertyType.Texture, Vector4.one),
	};

	readonly List<string> headers = new() {
		"PBR",
		"Normal Map 1",
		"Normal Map 2",
		"Occlusion",
		"Emission",
		"Rim",
		"Outline",
		"Reflection",
		"Vertex Colors",
		"Detail Map",
		"Layer 1",
		"Layer 2",
		"Layer 3",
		"Height Colors",
		"Shadow Overlay",
		"Plant Sway",
		"Camera Fade",
	};

	readonly List<string> stripDisplayNamePrefixes = new() {
		"Height Colors",
		"Shadow Overlay",
		"Plant Sway",
		"Outline",
	};

	enum PropertyType
	{
		Float, Vector, Texture
	};

	enum ExpandType
	{
		All,
		Active,
		Collapse,
		Keep,
	};

	ExpandType forceExpand = ExpandType.Active;
	readonly Dictionary<string, bool> headerOpenDic = new();
	readonly Dictionary<MaterialProperty, int> propOrder = new();
	bool isRenderingFoldoutOpen = true;
	bool isTransparentShader = false;

	static readonly Dictionary<string, GUIContent> toolTipsCache = new();

#if UNITY_2021_1_OR_NEWER && UNITY_PIPELINE_HDRP
    protected override void OnMaterialGUI(MaterialEditor materialEditor, MaterialProperty[] properties) 
#else
	public override void OnGUI(MaterialEditor materialEditor, MaterialProperty[] properties)
#endif
	{
		// Multi-selection
		var mat = materialEditor.target as Material;
		var mats = new List<Material>();
		if (mat != null)
			mats.Add(mat);
		foreach (var selected in Selection.objects)
		{
			if (selected.GetType() == typeof(Material))
			{
				var selectedMat = selected as Material;
				if (selectedMat != mat && selectedMat != null &&
					selectedMat.shader.name.Contains(UEisBetter.NAME))
					mats.Add(selectedMat);
			}
		}

		this.RenderGUI(materialEditor, properties);

		// Loop selected materials
		foreach (var material in mats)
		{
			this.AutoEnableShaderKeywords(material);
			if (material.shader.name.ToLower().Contains("transparent"))
				this.isTransparentShader = true;
		}
	}

	public override void ValidateMaterial(Material material)
	{
		// HDRP validation can rebuild a material's keyword set. Preserve the
		// pre-upgrade keyword state long enough to migrate it into serialized
		// properties, which are stable across shader imports and editor restarts.
		bool hadSurfaceOrmKeyword = material.IsKeywordEnabled(MetallicMapKeyword) ||
			material.IsKeywordEnabled(OcclusionMapKeyword);
		bool hadMetallicTextureKeyword = material.IsKeywordEnabled(MetallicTextureKeyword);
		bool hadRoughnessTextureKeyword = material.IsKeywordEnabled(RoughnessTextureKeyword);

		// Keep HDRP's generated Shader Graph state valid first, then restore the
		// UEisBetter feature keywords from their material properties. Unity invokes
		// this when a material is created, assigned, pasted, or reimported, so Rim
		// no longer depends on the inspector having been opened first.
		base.ValidateMaterial(material);
		if (hadSurfaceOrmKeyword && material.HasProperty(SurfaceOrmToggleProperty))
			material.SetFloat(SurfaceOrmToggleProperty, 1f);
		if (hadMetallicTextureKeyword && material.HasProperty(MetallicTextureToggleProperty))
			material.SetFloat(MetallicTextureToggleProperty, 1f);
		if (hadRoughnessTextureKeyword && material.HasProperty(RoughnessTextureToggleProperty))
			material.SetFloat(RoughnessTextureToggleProperty, 1f);
		AutoEnableShaderKeywords(material);
	}

	void AutoEnableShaderKeywords(Material mat)
	{
		ConfigureHDRPProperties(mat);

		foreach (var prop in UEisBetterGUI.props)
		{
			if (!mat.HasProperty(prop.name))
				continue;

			// Check if property value is being used (not set to default)
			bool isInUse = false;
			switch (prop.type)
			{
				case PropertyType.Float:
					isInUse = mat.GetFloat(prop.name) != prop.defaultValue.x;
					break;
				case PropertyType.Vector:
					isInUse = mat.GetVector(prop.name) != prop.defaultValue;
					break;
				case PropertyType.Texture:
					isInUse = mat.GetTexture(prop.name) != null;
					break;
				default:
					break;
			}

			// Enable or disable shader keyword
			if (isInUse)
			{
				if (!mat.IsKeywordEnabled(prop.keyword))
					mat.EnableKeyword(prop.keyword);
			}
			else if (mat.IsKeywordEnabled(prop.keyword))
				mat.DisableKeyword(prop.keyword);
		}

		this.AutoConfigureProperties(mat);
	}

	void AutoConfigureProperties(Material mat) {
		// Shader Graph boolean keywords are exposed as float properties. Explicitly
		// synchronize Rim so the custom GUI cannot leave the property and keyword
		// in different states after a graph reimport or shader reassignment.
		if (TryGetToggleProperty(mat, "Enable Rim Light", out bool rimEnabled))
			EnableDisableKeyword(mat, rimEnabled, "RIM_ON");

		// Surface ORM is an explicit material mode. Keep its metallic and
		// occlusion variants synchronized without inferring the mode from whether
		// a texture happens to be assigned.
		bool surfaceOrmEnabled = GetSerializedToggle(mat, SurfaceOrmToggleProperty,
			mat.IsKeywordEnabled(MetallicMapKeyword) || mat.IsKeywordEnabled(OcclusionMapKeyword));
		EnableDisableKeyword(mat, surfaceOrmEnabled, MetallicMapKeyword);
		EnableDisableKeyword(mat, surfaceOrmEnabled, OcclusionMapKeyword);

		// These are independent overrides. A separate texture wins over the
		// corresponding packed ORM channel; otherwise ORM or the scalar slider is
		// used. Read the generated Shader Graph toggle property when available so
		// HDRP keyword resets do not lose the serialized material choice.
		EnableDisableKeyword(mat,
			GetSerializedToggle(mat, MetallicTextureToggleProperty, mat.IsKeywordEnabled(MetallicTextureKeyword)),
			MetallicTextureKeyword);
		EnableDisableKeyword(mat,
			GetSerializedToggle(mat, RoughnessTextureToggleProperty, mat.IsKeywordEnabled(RoughnessTextureKeyword)),
			RoughnessTextureKeyword);

		// High Fresnel powers look correct on the spherical preview but collapse
		// to a sub-pixel band on flat meshes with narrow bevels. Migrate values
		// from the copied 0-25 range into UEisBetter's useful range.
		if (mat.HasProperty(RimSharpnessProperty)) {
			float sharpness = mat.GetFloat(RimSharpnessProperty);
			if (sharpness > MaximumRimSharpness) {
				mat.SetFloat(RimSharpnessProperty, MigratedRimSharpness);
				EditorUtility.SetDirty(mat);
			}
			else if (sharpness < MinimumRimSharpness) {
				mat.SetFloat(RimSharpnessProperty, MinimumRimSharpness);
				EditorUtility.SetDirty(mat);
			}
		}

		// Disable Reflection Mask With Rim if Reflection Disabled
		if (!mat.IsKeywordEnabled("REFLECTION_ON") &&
			mat.HasProperty("_ReflectionMaskWithRim") && mat.GetFloat("_ReflectionMaskWithRim") == 1)
			mat.SetFloat("_ReflectionMaskWithRim", 0);

		// Camera fade
		float fadeStart = mat.HasProperty("_CameraFadeStart") ? mat.GetFloat("_CameraFadeStart") : 0;
		float fadeEnd = mat.HasProperty("_CameraFadeEnd") ? mat.GetFloat("_CameraFadeEnd") : 0;
		bool cameraFadeEnabled = fadeStart < fadeEnd;
		EnableDisableKeyword(mat, cameraFadeEnabled, "CAMERA_FADE_ON");

#if !UNITY_PIPELINE_HDRP
		if (mat.HasProperty("_EmissionColor2")) {
			var emissionColor = mat.GetVector("_EmissionColor2");
			if ((Vector3)emissionColor != Vector3.zero)
				mat.globalIlluminationFlags = MaterialGlobalIlluminationFlags.BakedEmissive;
			else
				mat.globalIlluminationFlags = MaterialGlobalIlluminationFlags.EmissiveIsBlack;
		}
#endif
	}

	bool TryGetToggleProperty(Material mat, string displayName, out bool enabled) {
		enabled = false;
		var shader = mat.shader;
		for (int i = 0; i < shader.GetPropertyCount(); i++) {
			if (shader.GetPropertyDescription(i) != displayName)
				continue;

			string propertyName = shader.GetPropertyName(i);
			if (!mat.HasProperty(propertyName))
				return false;

			enabled = mat.GetFloat(propertyName) > 0.5f;
			return true;
		}
		return false;
	}

	void EnableDisableKeyword(Material mat, bool value, string keyword) {
		if (value) {
			if (!mat.IsKeywordEnabled(keyword))
				mat.EnableKeyword(keyword);
		}
		else {
			if (mat.IsKeywordEnabled(keyword))
				mat.DisableKeyword(keyword);
		}
	}

	public static void ConfigureHDRPProperties(Material mat) {
#if UNITY_PIPELINE_HDRP
		bool resetKeywords = false;
		if (mat.HasProperty("_AlphaCutoffEnable") && mat.GetFloat("_AlphaCutoffEnable") == 0) {
			mat.SetFloat("_AlphaCutoffEnable", 1);
			resetKeywords = true;
		}
		int isTransparent = mat.shader.name.Contains("Transparent") ? 1 : 0;
		if (mat.HasProperty("_SurfaceType") && mat.GetFloat("_SurfaceType") != isTransparent) {
			mat.SetFloat("_SurfaceType", isTransparent);
			resetKeywords = true;
		}
		
		if (resetKeywords)
			HDShaderUtils.ResetMaterialKeywords(mat);
#endif
	}

	void RenderGUI(MaterialEditor materialEditor, MaterialProperty[] properties) {
		materialEditor.SetDefaultGUIWidths();

		EditorGUILayout.HelpBox(
			"ORM channels: R = Occlusion, G = Roughness, B = Metallic. " +
			"Autodesk-compatible PBR: metallic and occlusion are used directly; roughness is converted " +
			"with smoothness = 1 - sqrt(roughness). Separate metallic and roughness textures use their " +
			"red channel and override ORM.",
			MessageType.Info);

		// Expand/Close all buttons
		GUILayout.BeginHorizontal();
		var expandAll = new GUIContent(EditorGUIUtility.IconContent("Toolbar Plus")) { text = "Expand All" };
		if (GUILayout.Button(expandAll))
			this.forceExpand = ExpandType.All;
		if (GUILayout.Button("Expand Active"))
			this.forceExpand = ExpandType.Active;
		var closeAll = new GUIContent(EditorGUIUtility.IconContent("Toolbar Minus")) { text = "Collapse" };
		if (GUILayout.Button(closeAll))
			this.forceExpand = ExpandType.Collapse;
		GUILayout.EndHorizontal();

		this.RenderShaderProperties(materialEditor, properties);

		// Append Unity rendering options to last group
		this.isRenderingFoldoutOpen = this.BeginFoldout(this.isRenderingFoldoutOpen, "Rendering");
		if (this.isRenderingFoldoutOpen) {
#if !(UNITY_2021_1_OR_NEWER && UNITY_PIPELINE_HDRP)
	#if !UNITY_PIPELINE_HDRP
			materialEditor.RenderQueueField();
	#endif
			materialEditor.EnableInstancingField();
			materialEditor.DoubleSidedGIField();
#else
			uiBlocks.RemoveAll(b => b is ShaderGraphUIBlock);
			base.OnMaterialGUI(materialEditor, properties);
#endif
		}
		EditorGUILayout.EndFoldoutHeaderGroup();
	}

	void RenderShaderProperties(MaterialEditor materialEditor, MaterialProperty[] properties) {
		this.RefreshPropertyHeaders(materialEditor);

		bool isFoldoutOpen = true;
		var headersVisited = new List<string>();
		this.SortProperties(properties);
		foreach (var prop in properties) {
			// Subgraph resource inputs are implementation details. Some Shader Graph
			// versions still surface them as generic "Texture2D" controls even when
			// hidden in the subgraph, so filter them explicitly.
			if (prop.name.StartsWith("Texture2D_UEIB_", StringComparison.Ordinal) ||
				prop.displayName == "Texture2D")
				continue;
			// Skip Unity vars
			if (prop.displayName.StartsWith("_") || prop.displayName.StartsWith("unity_"))
				continue;
			// Skip hidden vars
			#if UNITY_6000_1_OR_NEWER
			if ((prop.propertyFlags & ShaderPropertyFlags.HideInInspector) != 0)
			#else
			if ((prop.flags & MaterialProperty.PropFlags.HideInInspector) != 0)
			#endif
				continue;
			// Skip all caps
			if (this.IsAllUpper(prop.displayName))
				continue;
			// Skip camera fade on non-transparent shader
			if (!this.isTransparentShader && prop.displayName.StartsWith("Camera Fade"))
				continue;
				
			// Check if new header
			string headerName = this.GetHeaderName(prop.displayName);
			if (!string.IsNullOrEmpty(headerName) && !headersVisited.Contains(headerName)) {
				headersVisited.Add(headerName);
				bool isOpen = this.headerOpenDic[headerName];
				EditorGUILayout.EndFoldoutHeaderGroup();

				// Begin foldout header
				this.headerOpenDic[headerName] = isFoldoutOpen = this.BeginFoldout(isOpen, headerName);
			}

			// Render shader property
			if (isFoldoutOpen)
				this.RenderShaderProperty(materialEditor, prop);
		}
		EditorGUILayout.EndFoldoutHeaderGroup();
	}

	void RenderShaderProperty(MaterialEditor materialEditor, MaterialProperty prop) {
		var label = this.GetDisplayLabel(prop.displayName);

		if (prop.name == SurfaceOrmProperty) {
			this.RenderSurfaceOrmProperty(materialEditor, prop, label);
			return;
		}

		if (prop.name == MetallicTextureProperty) {
			this.RenderChannelTextureProperty(materialEditor, prop, label,
				"Use Metallic Texture", MetallicTextureToggleProperty, MetallicTextureKeyword);
			return;
		}

		if (prop.name == RoughnessTextureProperty) {
			this.RenderChannelTextureProperty(materialEditor, prop, label,
				"Use Roughness Texture", RoughnessTextureToggleProperty, RoughnessTextureKeyword);
			return;
		}

		if (prop.name == MetallicProperty) {
			using (new EditorGUI.DisabledScope(this.IsSurfaceOrmEnabled(materialEditor) ||
				this.IsChannelTextureEnabled(materialEditor, MetallicTextureToggleProperty, MetallicTextureKeyword)))
				materialEditor.ShaderProperty(prop, this.GetTooltip(label));
			return;
		}

		if (prop.name == SmoothnessProperty) {
			using (new EditorGUI.DisabledScope(this.IsSurfaceOrmEnabled(materialEditor) ||
				this.IsChannelTextureEnabled(materialEditor, RoughnessTextureToggleProperty, RoughnessTextureKeyword)))
				materialEditor.ShaderProperty(prop, this.GetTooltip(label));
			return;
		}

		// Shader Graph exposes Boolean keywords as float properties. Drawing Rim
		// explicitly keeps its serialized value and local keyword synchronized in
		// the same UI event (including multi-object editing).
		if (prop.displayName == "Enable Rim Light") {
			var content = this.GetTooltip(label);
			EditorGUI.showMixedValue = prop.hasMixedValue;
			EditorGUI.BeginChangeCheck();
			bool enabled = EditorGUILayout.Toggle(content, prop.floatValue > 0.5f);
			if (EditorGUI.EndChangeCheck()) {
				materialEditor.RegisterPropertyChangeUndo(content.text);
				prop.floatValue = enabled ? 1f : 0f;
				foreach (var target in materialEditor.targets.OfType<Material>()) {
					target.SetFloat(prop.name, enabled ? 1f : 0f);
					EnableDisableKeyword(target, enabled, "RIM_ON");
					EditorUtility.SetDirty(target);
				}
				// Notify HDRP/SRP-batched scene renderers that the material's local
				// shader variant changed, not only the Inspector preview.
				materialEditor.PropertiesChanged();
				SceneView.RepaintAll();
			}
			EditorGUI.showMixedValue = false;
			return;
		}

		if (prop.displayName == "Enable Outline") {
			var content = this.GetTooltip(label);
			EditorGUI.showMixedValue = prop.hasMixedValue;
			EditorGUI.BeginChangeCheck();
			bool enabled = EditorGUILayout.Toggle(content, prop.floatValue > 0.5f);
			if (EditorGUI.EndChangeCheck()) {
				materialEditor.RegisterPropertyChangeUndo(content.text);
				prop.floatValue = enabled ? 1f : 0f;
				foreach (var target in materialEditor.targets.OfType<Material>()) {
					target.SetFloat(prop.name, enabled ? 1f : 0f);
					EditorUtility.SetDirty(target);
				}
#if UNITY_PIPELINE_HDRP
				UEisBetterOutlinePass.InvalidateRendererCache();
#endif
				materialEditor.PropertiesChanged();
				SceneView.RepaintAll();
			}
			EditorGUI.showMixedValue = false;
			return;
		}

		if (prop.displayName.StartsWith("Outline ")) {
			using (new EditorGUI.DisabledScope(!this.IsOutlineEnabled(materialEditor)))
				materialEditor.ShaderProperty(prop, this.GetTooltip(label));
			return;
		}

		if (prop.displayName == "Rim Contrast") {
			var content = this.GetTooltip(label);
			EditorGUI.showMixedValue = prop.hasMixedValue;
			EditorGUI.BeginChangeCheck();
			float sharpness = EditorGUILayout.Slider(
				content,
				Mathf.Clamp(prop.floatValue, MinimumRimSharpness, MaximumRimSharpness),
				MinimumRimSharpness,
				MaximumRimSharpness);
			if (EditorGUI.EndChangeCheck()) {
				materialEditor.RegisterPropertyChangeUndo(content.text);
				prop.floatValue = sharpness;
				foreach (var target in materialEditor.targets.OfType<Material>()) {
					target.SetFloat(prop.name, sharpness);
					EditorUtility.SetDirty(target);
				}
				materialEditor.PropertiesChanged();
				SceneView.RepaintAll();
			}
			EditorGUI.showMixedValue = false;
			return;
		}

		// Show tiling/offset for textures
		#if UNITY_6000_1_OR_NEWER
		bool isTextureProperty = prop.propertyType == ShaderPropertyType.Texture;
		#else
		bool isTextureProperty = prop.type == MaterialProperty.PropType.Texture;
		#endif
		if (isTextureProperty && label != "Reflection Map")
			materialEditor.TextureProperty(prop, label, true);
		else {
			var content = this.GetTooltip(label);
			materialEditor.ShaderProperty(prop, content);
		}
	}

	void RenderSurfaceOrmProperty(MaterialEditor materialEditor, MaterialProperty prop, string label) {
		var materials = materialEditor.targets.OfType<Material>().ToArray();
		bool enabled = materials.Length > 0 && this.IsSurfaceOrmEnabled(materials[0]);
		bool mixed = materials.Any(material => this.IsSurfaceOrmEnabled(material) != enabled);

		EditorGUI.showMixedValue = mixed;
		EditorGUI.BeginChangeCheck();
		bool useTexture = EditorGUILayout.Toggle(this.GetTooltip("Use Surface ORM Map"), enabled);
		if (EditorGUI.EndChangeCheck()) {
			materialEditor.RegisterPropertyChangeUndo("Use Surface ORM Map");
			foreach (var material in materials) {
				SetSerializedToggle(material, SurfaceOrmToggleProperty, useTexture);
				EnableDisableKeyword(material, useTexture, MetallicMapKeyword);
				EnableDisableKeyword(material, useTexture, OcclusionMapKeyword);
				EditorUtility.SetDirty(material);
			}
			materialEditor.PropertiesChanged();
			SceneView.RepaintAll();
			enabled = useTexture;
		}
		EditorGUI.showMixedValue = false;

		materialEditor.TextureProperty(prop, label, true);
		if (enabled && prop.textureValue == null)
			EditorGUILayout.HelpBox("Surface ORM mode is enabled, but no ORM texture is assigned.", MessageType.Warning);
	}

	void RenderChannelTextureProperty(
		MaterialEditor materialEditor,
		MaterialProperty prop,
		string label,
		string toggleLabel,
		string toggleProperty,
		string keyword) {
		var materials = materialEditor.targets.OfType<Material>().ToArray();
		bool enabled = materials.Length > 0 &&
			this.IsChannelTextureEnabled(materials[0], toggleProperty, keyword);
		bool mixed = materials.Any(material =>
			this.IsChannelTextureEnabled(material, toggleProperty, keyword) != enabled);

		EditorGUI.showMixedValue = mixed;
		EditorGUI.BeginChangeCheck();
		bool useTexture = EditorGUILayout.Toggle(this.GetTooltip(toggleLabel), enabled);
		if (EditorGUI.EndChangeCheck()) {
			materialEditor.RegisterPropertyChangeUndo(toggleLabel);
			foreach (var material in materials) {
				SetSerializedToggle(material, toggleProperty, useTexture);
				EnableDisableKeyword(material, useTexture, keyword);
				EditorUtility.SetDirty(material);
			}
			materialEditor.PropertiesChanged();
			SceneView.RepaintAll();
			enabled = useTexture;
		}
		EditorGUI.showMixedValue = false;

		using (new EditorGUI.DisabledScope(!enabled))
			materialEditor.TextureProperty(prop, label, true);
		if (enabled && prop.textureValue == null)
			EditorGUILayout.HelpBox($"{toggleLabel} is enabled, but no texture is assigned.", MessageType.Warning);
	}

	bool IsChannelTextureEnabled(MaterialEditor materialEditor, string toggleProperty, string keyword) {
		return materialEditor.targets.OfType<Material>().Any(material =>
			this.IsChannelTextureEnabled(material, toggleProperty, keyword));
	}

	bool IsChannelTextureEnabled(Material material, string toggleProperty, string keyword) {
		return GetSerializedToggle(material, toggleProperty, material.IsKeywordEnabled(keyword));
	}

	static bool GetSerializedToggle(Material material, string propertyName, bool fallback) {
		return material.HasProperty(propertyName) ? material.GetFloat(propertyName) > 0.5f : fallback;
	}

	static void SetSerializedToggle(Material material, string propertyName, bool enabled) {
		if (material.HasProperty(propertyName))
			material.SetFloat(propertyName, enabled ? 1f : 0f);
	}

	bool IsSurfaceOrmEnabled(MaterialEditor materialEditor) {
		return materialEditor.targets.OfType<Material>().Any(this.IsSurfaceOrmEnabled);
	}

	bool IsSurfaceOrmEnabled(Material material) {
		return GetSerializedToggle(material, SurfaceOrmToggleProperty,
			material.IsKeywordEnabled(MetallicMapKeyword) || material.IsKeywordEnabled(OcclusionMapKeyword));
	}

	bool IsOutlineEnabled(MaterialEditor materialEditor) {
		return materialEditor.targets.OfType<Material>().Any(this.IsOutlineEnabled);
	}

	bool IsOutlineEnabled(Material material) {
		return material.HasProperty(OutlineEnabledProperty) &&
			material.GetFloat(OutlineEnabledProperty) > 0.5f;
	}

	string GetDisplayLabel(string displayName) {
		var label = displayName;
		foreach (string prefix in stripDisplayNamePrefixes) {
			if (label.StartsWith(prefix))
				label = label.Replace(prefix + " ", string.Empty);
		}

		if (label == "Metallic Surface ORM Map")
			label = "Surface ORM Map";
		else if (label == "Metallic Smoothness")
			label = "Smoothness";
		else if (label == "Rim Contrast")
			label = "Rim Contrast / Bias";
		else if (label.StartsWith("Detail Map Use"))
			label = label.Replace("Detail Map ", string.Empty);
		else if (label.Contains("Mask With"))
			label = label.Substring(label.IndexOf("Mask"));
		else
			label = label.Replace("Rendering ", string.Empty);
		return label;
	}

	void RefreshPropertyHeaders(MaterialEditor materialEditor) {
		var mat = materialEditor.target as Material;
		var shader = mat.shader;

		// Initialize to all close if keep active
		if (this.forceExpand == ExpandType.Active) {
			var headers = new List<string>(this.headerOpenDic.Keys);
			foreach (var header in headers)
				this.headerOpenDic[header] = false;
		}

		int numProps = shader.GetPropertyCount();
		var newHeaders = new List<string>();
		for (int i = 0; i < numProps; i++) {
			// Skip if not part of a header group
			string propDesc = shader.GetPropertyDescription(i);
			var propType = shader.GetPropertyType(i);
			string headerName = this.GetHeaderName(propDesc);

			if (string.IsNullOrEmpty(headerName))
				continue;

			// Skip if not a key property that can toggle a group
			if (!this.IsKeyProperty(propDesc, propType))
				continue;

			newHeaders.Add(headerName);

			// Check if property active
			bool isInUse = false;
			switch (this.forceExpand) {
				case ExpandType.All:
					isInUse = true;
					this.isRenderingFoldoutOpen = true;
					break;
				case ExpandType.Active:
					string propName = shader.GetPropertyName(i);
					isInUse = this.IsPropertyActive(mat, propName, propDesc, propType);
					this.isRenderingFoldoutOpen = true;
					break;
				case ExpandType.Collapse:
					isInUse = false;
					this.isRenderingFoldoutOpen = false;
					break;
				default: 
					break;
			}

			// Cache
			if (!this.headerOpenDic.ContainsKey(headerName))
				this.headerOpenDic.Add(headerName, isInUse);
			if (this.forceExpand == 0 || this.forceExpand == ExpandType.Active)
				this.headerOpenDic[headerName] |= isInUse;
			else if (this.forceExpand == ExpandType.Collapse)
				this.headerOpenDic[headerName] = isInUse;
		}
		this.forceExpand = ExpandType.Keep;

		// Remove any headers that were deleted
		var deletedHeaders = this.headerOpenDic.Keys.Except(newHeaders);
		foreach (var deletedHeader in deletedHeaders)
			this.headerOpenDic.Remove(deletedHeader);
	}

	bool IsKeyProperty(string propDesc, ShaderPropertyType propType) {
		var keyProps = new List<string>() {
			"Metallic",
			"Emission Color",
			"Camera Fade Start Distance",
		};

		return (propType == ShaderPropertyType.Float && propDesc.StartsWith("Enable")) ||
			propType == ShaderPropertyType.Texture || keyProps.Contains(propDesc);
	}

	bool IsPropertyActive(Material mat, string propName, string propDesc, ShaderPropertyType propType) {
		if (!mat.HasProperty(propName))
			return false;

		if ((propType == ShaderPropertyType.Float && propDesc.StartsWith("Enable") && mat.GetFloat(propName) == 1) ||
			(propType == ShaderPropertyType.Texture && mat.GetTexture(propName) != null) ||
			propDesc == "Metallic" ||
			(propDesc == "Emission Color" && (Vector3)mat.GetVector(propName) != Vector3.zero) ||
			(propName == "_CameraFadeStart" && mat.IsKeywordEnabled("CAMERA_FADE_ON")))
			return true;
		return false;
	}

	void SortProperties(MaterialProperty[] properties) {
		// Preserve original order
		this.propOrder.Clear();
		for (int i = 0; i < properties.Length; i++)
			this.propOrder.Add(properties[i], i);
		Array.Sort(properties, PropertyComparer);
	}

	int PropertyComparer(MaterialProperty a, MaterialProperty b) {
		// Sort in order of not grouped, groups by order of header, keyword or not
		int headerA = this.headers.IndexOf(this.GetHeaderName(a.displayName));
		int headerB = this.headers.IndexOf(this.GetHeaderName(b.displayName));
		if (headerA != headerB)
			return headerA < headerB ? -1 : 1;
		else {
			bool keywordA = a.displayName.Contains("Enable");
			bool keywordB = b.displayName.Contains("Enable");
			if (keywordA && !keywordB)
				return -1;
			else if (!keywordA && keywordB)
				return 1;
			else {  // Preserve original order
				if (this.propOrder[a] < this.propOrder[b])
					return -1;
				else if (this.propOrder[a] > this.propOrder[b])
					return 1;
				else
					return 0;
			}
		}
	}

	string GetHeaderName(string propDesc) {
		if (this.IsPbrProperty(propDesc))
			return "PBR";

		foreach (var header in this.headers) {
			if (propDesc.Contains(header))
				return header;
		}
		return string.Empty;
	}

	bool IsPbrProperty(string propDesc) {
		return propDesc == "Metallic" ||
			propDesc == "Metallic Smoothness" ||
			propDesc == "Smoothness" ||
			propDesc == "Metallic Surface ORM Map" ||
			propDesc == "Surface ORM Map" ||
			propDesc == "Metallic Texture" ||
			propDesc == "Roughness Texture" ||
			propDesc == "Use Surface ORM Map" ||
			propDesc == "Use Metallic Texture" ||
			propDesc == "Use Roughness Texture";
	}

	bool BeginFoldout(bool isOpen, string name) {
		var content = this.GetTooltip(name);
		var defaultColor = GUI.backgroundColor;
		GUI.backgroundColor = new Color(1.35f, 1.35f, 1.35f);
		bool retVal = EditorGUILayout.BeginFoldoutHeaderGroup(isOpen, content);
		GUI.backgroundColor = defaultColor;
		return retVal;
	}

	GUIContent GetTooltip(string label) {
		// Check cache first
		if (UEisBetterGUI.toolTipsCache.ContainsKey(label))
			return UEisBetterGUI.toolTipsCache[label];

		string tooltip;
		switch (label) {
			case "Ignore Main Texture Alpha": tooltip = "Ignore the alpha channel on the texture, forcing it to be opaque."; break;
			case "Rim Direction": tooltip = "Rim light direction in world space."; break;
			case "Rim Contrast / Bias": tooltip = "Controls the Fresnel bias/falloff. Lower values produce a wider rim; higher values push the rim toward grazing angles and make it thinner."; break;
			case "Enable Outline": tooltip = "Draw an unlit expanded shell only for renderers using this material. This is independent of scene lighting and does not use Fresnel."; break;
			case "Color": tooltip = "The geometry outline color. HDR colors are supported."; break;
			case "Width": tooltip = "Outline expansion in world units."; break;
			case "Opacity": tooltip = "Overall opacity of the geometry outline."; break;
			case "Bias": tooltip = "Offsets the configured outline width. -1 removes the expansion, 0 keeps Width unchanged, and 1 doubles it."; break;
			case "Contrast": tooltip = "Scales outline brightness. Values below 1 dim it; values above 1 increase HDR intensity."; break;
			case "Exposure Compensation": tooltip = "Keep the outline brightness stable when HDRP exposure changes."; break;
			case "Use Surface ORM Map": tooltip = "When enabled, R is direct occlusion, G is Autodesk perceptual roughness, and B is direct metallic. Metallic and Smoothness sliders are ignored and disabled."; break;
			case "Use Metallic Texture": tooltip = "Use the separate metallic texture's red channel. This overrides packed ORM metallic and disables the Metallic slider."; break;
			case "Use Roughness Texture": tooltip = "Use the separate roughness texture's red channel with Autodesk perceptual conversion: smoothness = 1 - sqrt(roughness). This overrides packed ORM roughness and disables the Smoothness slider."; break;
			case "Metallic Texture": tooltip = "Linear metallic data read from the red channel. Disable sRGB on this texture."; break;
			case "Roughness Texture": tooltip = "Linear roughness data read from the red channel and converted with smoothness = 1 - sqrt(roughness), matching Autodesk Interactive. Disable sRGB on this texture."; break;
			case "Mask With Rim": tooltip = "Mask the reflection with the rim's fresnel effect to simulate reflections only at glancing angles."; break;
			case "Use Alpha Blend Instead Of Multiply": tooltip = "Blend using the alpha value instead of multiplying the detail map."; break;
			case "Mask With Vertex Color (A)": tooltip = "Mask with the vertex color's alpha channel."; break;
			case "Mask With Vertex Color (R)": tooltip = "Mask with the vertex color's red channel."; break;
			case "Mask With Vertex Color (G)": tooltip = "Mask with the vertex color's green channel."; break;
			case "Mask With Vertex Color (B)": tooltip = "Mask with the vertex color's blue channel."; break;
			case "Height Colors": tooltip = "Apply a color to the object based on its local or world-space height."; break;
			case "Enable Height Colors": tooltip = "Apply a color to the object based on its local or world-space height."; break;
			case "Use Local Space Instead Of World Space": tooltip = "Use local space instead of world space for height calculation."; break;
			default: tooltip = ""; break;
		}

		// Create tool tip and cache
		var content = new GUIContent() {
			text = label,
			tooltip = tooltip
		};
		UEisBetterGUI.toolTipsCache.Add(label, content);
		return content;
	}

	bool IsAllUpper(string str) {
		foreach (char c in str) {
			if (Char.IsLetter(c) && !Char.IsUpper(c))
				return false;
		}
		return true;
	}

	public override void AssignNewShaderToMaterial(Material mat, Shader oldShader, Shader newShader) {
		// Convert texture mapping
		var textureMapping = new Dictionary<string, string>() {
			{ "_MainTex", "_BaseMap" },
			{ "_BaseColorMap", "_BaseMap" },
			{ "_EmissiveColorMap", "_EmissionMap" },
			{ "_NormalMap", "_BumpMap" },
		};
		var tilingOffsetMapping = new Dictionary<string, Vector4>();

		// Fetch textures from mapping
		var texToReplace = new Dictionary<string, Texture>();
		foreach (var texMap in textureMapping) {
			if (mat.HasProperty(texMap.Key) && mat.GetTexture(texMap.Key) != null) {
				if (!texToReplace.ContainsKey(texMap.Value)) {
					texToReplace.Add(texMap.Value, mat.GetTexture(texMap.Key));

					// Store tiling offset
					Vector4 tilingOffset;
					Vector2 tiling, offset;
					tiling = mat.GetTextureScale(texMap.Key);
					offset = mat.GetTextureOffset(texMap.Key);
					tilingOffset.x = tiling.x;
					tilingOffset.y = tiling.y;
					tilingOffset.z = offset.x;
					tilingOffset.w = offset.y;
					tilingOffsetMapping.Add(texMap.Value, tilingOffset);
				}
				mat.SetTexture(texMap.Key, null);
			}
		}
		// Get specific properties           
		Vector4 baseColor = Vector4.one;
		Vector4 emissionColor = Vector4.zero;
		float smoothness = 0.5f, bumpScale = 1.0f;
		if (mat.HasProperty("_BaseColor"))
			baseColor = mat.GetVector("_BaseColor");
		else if (mat.HasProperty("_Color"))
			baseColor = mat.GetVector("_Color");
		if (mat.HasProperty("_Smoothness"))
			smoothness = mat.GetFloat("_Smoothness");
		if (mat.HasProperty("_NormalScale"))
			bumpScale = mat.GetFloat("_NormalScale");
		else if (mat.HasProperty("_BumpScale"))
			bumpScale = mat.GetFloat("_BumpScale");
		if (mat.HasProperty("_EmissiveColor"))
			emissionColor = mat.GetVector("_EmissiveColor");
		else if (mat.HasProperty("_EmissionColor2"))
			emissionColor = mat.GetVector("_EmissionColor2");
		else if (mat.HasProperty("_EmissionColor") && mat.globalIlluminationFlags != MaterialGlobalIlluminationFlags.EmissiveIsBlack)
			emissionColor = mat.GetVector("_EmissionColor");

		// Replace shader
		base.AssignNewShaderToMaterial(mat, oldShader, newShader);

		// Replace textures
		Vector2 baseTiling = Vector2.one, baseOffset = Vector2.zero;
		foreach (var texToRep in texToReplace) {
			var texName = texToRep.Key;
			if (mat.HasProperty(texName)) {
				mat.SetTexture(texName, texToRep.Value);
				if (tilingOffsetMapping.ContainsKey(texName)) {
					// Restore tiling offset
					Vector4 tilingOffset = tilingOffsetMapping[texName];
					Vector2 tiling = (Vector2)tilingOffset;
					Vector2 offset;
					offset.x = tilingOffset.z;
					offset.y = tilingOffset.w;
					mat.SetTextureScale(texName, tiling);
					mat.SetTextureOffset(texName, offset);

					// Store base tiling offset
					if (texName == "_BaseMap") {
						baseTiling = tiling;
						baseOffset = offset;
					}
				}
			}
		}

		// If prev shader is Lit, apply base tiling offset to all tex
		if (oldShader.name.Contains("Lit") || oldShader.name == "Standard") {
			foreach (var texMap in textureMapping) {
				var texName = texMap.Value;
				if (mat.HasProperty(texName)) {
					mat.SetTextureScale(texName, baseTiling);
					mat.SetTextureOffset(texName, baseOffset);
				}
			}
		}

		// Replace properties
		mat.SetVector("_BaseColor", baseColor);
		mat.SetVector("_EmissionColor2", emissionColor);
		mat.SetFloat("_Smoothness", smoothness);
		mat.SetFloat("_BumpScale", bumpScale);
		if ((Vector3)emissionColor != Vector3.zero)
			mat.globalIlluminationFlags = MaterialGlobalIlluminationFlags.BakedEmissive;

		this.forceExpand = ExpandType.Active;
	}
}
