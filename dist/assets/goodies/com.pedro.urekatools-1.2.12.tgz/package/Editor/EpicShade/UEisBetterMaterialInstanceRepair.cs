using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

[InitializeOnLoad]
public static class UEisBetterMaterialInstanceRepair
{
    private const string MenuPath = "UrekaTools/EpicShade/Repair Detached Material Instances";
    private const string InstanceSuffix = " (Instance)";

    static UEisBetterMaterialInstanceRepair()
    {
        // A detached EpicShade material cannot receive edits made to its .mat asset.
        // Repair these after a domain reload so imported projects and existing
        // scenes recover without requiring a hidden manual setup step.
        EditorApplication.delayCall += RepairDetachedUEisBetterInstancesOnLoad;
    }

    [MenuItem(MenuPath)]
    private static void RepairDetachedMaterialInstances()
    {
        RepairDetachedMaterialInstances(true, true);
    }

    private static void RepairDetachedUEisBetterInstancesOnLoad()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode)
            return;

        RepairDetachedMaterialInstances(false, false);
    }

    private static void RepairDetachedMaterialInstances(bool includeOmniShade, bool logWhenNoneFound)
    {
        var renderers = Resources.FindObjectsOfTypeAll<Renderer>();
        var materialCache = new Dictionary<string, Material>();
        var repairedRenderers = 0;
        var repairedSlots = 0;

        foreach (var renderer in renderers)
        {
            if (renderer == null || EditorUtility.IsPersistent(renderer) ||
                !renderer.gameObject.scene.IsValid() || !renderer.gameObject.scene.isLoaded)
            {
                continue;
            }

            var materials = renderer.sharedMaterials;
            var rendererChanged = false;

            for (var i = 0; i < materials.Length; i++)
            {
                var instance = materials[i];
                if (!IsDetachedSupportedMaterial(instance, includeOmniShade))
                    continue;

                var assetName = instance.name.Substring(0, instance.name.Length - InstanceSuffix.Length);
                var asset = FindMatchingMaterialAsset(assetName, instance.shader, materialCache);
                if (asset == null)
                {
                    Debug.LogWarning(
                        $"[EpicShade] Could not find one unambiguous material asset for detached " +
                        $"instance '{instance.name}' on '{renderer.name}'.",
                        renderer);
                    continue;
                }

                if (!rendererChanged)
                    Undo.RecordObject(renderer, "Repair detached material instance");

                materials[i] = asset;
                rendererChanged = true;
                repairedSlots++;
            }

            if (!rendererChanged)
                continue;

            renderer.sharedMaterials = materials;
            PrefabUtility.RecordPrefabInstancePropertyModifications(renderer);
            EditorSceneManager.MarkSceneDirty(renderer.gameObject.scene);
            EditorUtility.SetDirty(renderer);
            repairedRenderers++;
        }

        if (repairedSlots == 0)
        {
            if (logWhenNoneFound)
            {
                Debug.Log(
                    "[EpicShade] No detached EpicShade or OmniShade material instances were found in loaded scenes.");
            }

            return;
        }

        SceneView.RepaintAll();
        Debug.Log(
            $"[EpicShade] Repaired {repairedSlots} detached material slot(s) on " +
            $"{repairedRenderers} renderer(s). Save the scene or prefab to keep these assignments.");
    }

    [MenuItem(MenuPath, true)]
    private static bool ValidateRepairDetachedMaterialInstances()
    {
        return !EditorApplication.isPlayingOrWillChangePlaymode;
    }

    private static bool IsDetachedSupportedMaterial(Material material, bool includeOmniShade)
    {
        if (material == null || material.shader == null ||
            !material.name.EndsWith(InstanceSuffix, StringComparison.Ordinal) ||
            !string.IsNullOrEmpty(AssetDatabase.GetAssetPath(material)))
        {
            return false;
        }

        var shaderName = material.shader.name;
        return shaderName.StartsWith("EpicShade/", StringComparison.Ordinal) ||
               shaderName.StartsWith("UEisBetter/", StringComparison.Ordinal) ||
               includeOmniShade && shaderName.StartsWith("OmniShade", StringComparison.Ordinal);
    }

    private static Material FindMatchingMaterialAsset(
        string assetName,
        Shader instanceShader,
        Dictionary<string, Material> cache)
    {
        var cacheKey = assetName + "\n" + instanceShader.name;
        if (cache.TryGetValue(cacheKey, out var cachedMaterial))
            return cachedMaterial;

        Material onlyExactNameMatch = null;
        var exactNameMatchCount = 0;

        // Search all material assets and compare names exactly. Name-filtered
        // AssetDatabase searches tokenize underscores, which can miss names such
        // as M_FarmSign on some Unity versions.
        foreach (var guid in AssetDatabase.FindAssets("t:Material"))
        {
            var path = AssetDatabase.GUIDToAssetPath(guid);
            var candidate = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (candidate == null || !string.Equals(candidate.name, assetName, StringComparison.Ordinal))
                continue;

            exactNameMatchCount++;
            onlyExactNameMatch = candidate;

            if (candidate.shader == instanceShader)
            {
                cache[cacheKey] = candidate;
                return candidate;
            }
        }

        var result = exactNameMatchCount == 1 ? onlyExactNameMatch : null;
        cache[cacheKey] = result;
        return result;
    }
}
