using System;
using System.Linq;
using UnityEditor;
using UnityEditor.PackageManager;
using UnityEditor.PackageManager.Requests;
using UnityEngine;

public static class UrekaToolsPackageExporter
{
    const string Root = "Packages/com.pedro.urekatools";
    const string ForbiddenDependencyRoot = "Assets/OmniShade PBR/";
	static PackRequest packRequest;

    [MenuItem("UrekaTools/EpicShade/Validate Package", false, 200)]
    public static void ValidateMenu()
    {
        ValidateDependencies(true);
    }

    [MenuItem("UrekaTools/Export UrekaTools Package", false, 300)]
    public static void ExportPackage()
    {
        if (!ValidateDependencies(true))
            return;

        var outputFolder = EditorUtility.OpenFolderPanel(
            "Export UrekaTools UPM Package",
            string.Empty,
            string.Empty);
        if (string.IsNullOrWhiteSpace(outputFolder))
            return;

		packRequest = Client.Pack(Root, outputFolder);
		EditorApplication.update += MonitorPackRequest;
    }

	static void MonitorPackRequest()
	{
		if (packRequest == null || !packRequest.IsCompleted)
			return;

		EditorApplication.update -= MonitorPackRequest;
		if (packRequest.Status == StatusCode.Success)
		{
			Debug.Log($"Exported UrekaTools UPM package to {packRequest.Result.tarballPath}");
			EditorUtility.RevealInFinder(packRequest.Result.tarballPath);
		}
		else
		{
			Debug.LogError($"UrekaTools package export failed: {packRequest.Error?.message}");
		}
		packRequest = null;
	}

    static bool ValidateDependencies(bool showDialog)
    {
        var forbidden = AssetDatabase.GetDependencies(Root, true)
            .Where(path => path.StartsWith(ForbiddenDependencyRoot, StringComparison.OrdinalIgnoreCase))
            .OrderBy(path => path)
            .ToArray();

        if (forbidden.Length == 0)
        {
            if (showDialog)
                EditorUtility.DisplayDialog("UrekaTools", "Validation passed. The package is self-contained and has no external OmniShade asset references.", "OK");
            return true;
        }

        var message = "EpicShade still references OmniShade assets:\n\n" + string.Join("\n", forbidden);
        Debug.LogError(message);
        if (showDialog)
            EditorUtility.DisplayDialog("UrekaTools validation failed", message, "OK");
        return false;
    }
}
