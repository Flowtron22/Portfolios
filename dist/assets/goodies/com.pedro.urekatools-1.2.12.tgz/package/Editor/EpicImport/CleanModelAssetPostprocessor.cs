using UnityEditor;
using UnityEngine;

namespace TGC.CleanModelImporter
{
    internal sealed class CleanModelAssetPostprocessor : AssetPostprocessor
    {
        void OnPreprocessModel()
        {
            var settings = CleanModelImporterSettings.instance;
            if (!settings.ShouldProcess(assetPath) || assetImporter is not ModelImporter importer)
                return;

            importer.bakeAxisConversion = settings.BakeAxisConversion;
            importer.useFileScale = settings.UseFileScale;
            importer.globalScale = 1f;
            importer.preserveHierarchy = settings.PreserveHierarchy;
            importer.materialImportMode = settings.ImportMaterials
                ? ModelImporterMaterialImportMode.ImportStandard
                : ModelImporterMaterialImportMode.None;
        }

        static void OnPostprocessAllAssets(string[] importedAssets, string[] deletedAssets,
            string[] movedAssets, string[] movedFromAssetPaths, bool didDomainReload)
        {
            foreach (var importedAsset in importedAssets)
            {
                if (CleanModelImporterSettings.instance.ShouldProcess(importedAsset))
                    CleanModelImportQueue.Enqueue(importedAsset);
            }
        }
    }
}
