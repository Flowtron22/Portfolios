using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace TGC.CleanModelImporter
{
    internal enum CleanPivotMode
    {
        SourceOrigin,
        Marker,
        BoundsCenter,
        BoundsBottomCenter
    }

    [FilePath("ProjectSettings/CleanModelImporterSettings.asset", FilePathAttribute.Location.ProjectFolder)]
    internal sealed class CleanModelImporterSettings : ScriptableSingleton<CleanModelImporterSettings>
    {
        [SerializeField] bool enabled = true;
        [SerializeField] string watchedFolder = "Assets/ModelImports";
        [SerializeField] bool bakeAxisConversion = true;
        [SerializeField] bool useFileScale = true;
        [SerializeField] bool preserveHierarchy = true;
        [SerializeField] bool importMaterials = true;
        [SerializeField] bool autoExtractTextures = true;
        [SerializeField] bool copySidecarTextures = true;
        [SerializeField] bool autoExtractMaterials = true;
        [SerializeField] bool applyUEisBetterShader = true;
        [SerializeField] bool buildPackedOrm = true;
        [SerializeField] bool generateCleanPrefab = true;
        [SerializeField] CleanPivotMode pivotMode = CleanPivotMode.SourceOrigin;
        [SerializeField] string pivotMarkerName = "__PIVOT__";
        [SerializeField] bool hidePivotMarker = true;

        internal bool Enabled { get => enabled; set => enabled = value; }
        internal string WatchedFolder { get => watchedFolder; set => watchedFolder = NormalizeFolder(value); }
        internal bool BakeAxisConversion { get => bakeAxisConversion; set => bakeAxisConversion = value; }
        internal bool UseFileScale { get => useFileScale; set => useFileScale = value; }
        internal bool PreserveHierarchy { get => preserveHierarchy; set => preserveHierarchy = value; }
        internal bool ImportMaterials { get => importMaterials; set => importMaterials = value; }
        internal bool AutoExtractTextures { get => autoExtractTextures; set => autoExtractTextures = value; }
        internal bool CopySidecarTextures { get => copySidecarTextures; set => copySidecarTextures = value; }
        internal bool AutoExtractMaterials { get => autoExtractMaterials; set => autoExtractMaterials = value; }
        // Keep the serialized field name above so existing project settings migrate without data loss.
        internal bool ApplyEpicShadeShader { get => applyUEisBetterShader; set => applyUEisBetterShader = value; }
        internal bool BuildPackedOrm { get => buildPackedOrm; set => buildPackedOrm = value; }
        internal bool GenerateCleanPrefab { get => generateCleanPrefab; set => generateCleanPrefab = value; }
        internal CleanPivotMode PivotMode { get => pivotMode; set => pivotMode = value; }
        internal string PivotMarkerName { get => pivotMarkerName; set => pivotMarkerName = value; }
        internal bool HidePivotMarker { get => hidePivotMarker; set => hidePivotMarker = value; }

        internal void SaveSettings() => Save(true);

        internal bool ShouldProcess(string assetPath)
        {
            if (!enabled || !CleanModelImportUtility.IsSupportedModelPath(assetPath))
                return false;

            var normalizedPath = assetPath.Replace('\\', '/');
            var importer = AssetImporter.GetAtPath(assetPath);
            if (importer != null && CleanModelImportUtility.HasFlag(importer.userData, CleanModelImportUtility.DisabledFlag))
                return false;

            var folder = NormalizeFolder(watchedFolder).TrimEnd('/');
            if (!string.IsNullOrWhiteSpace(folder) &&
                (normalizedPath.Equals(folder, StringComparison.OrdinalIgnoreCase) ||
                 normalizedPath.StartsWith(folder + "/", StringComparison.OrdinalIgnoreCase)))
                return true;

            return importer != null && CleanModelImportUtility.HasFlag(importer.userData, CleanModelImportUtility.EnabledFlag);
        }

        internal static string NormalizeFolder(string value)
        {
            var normalized = string.IsNullOrWhiteSpace(value) ? "Assets/ModelImports" : value.Trim().Replace('\\', '/').TrimEnd('/');
            return normalized.Equals("Assets", StringComparison.Ordinal) ||
                   normalized.StartsWith("Assets/", StringComparison.Ordinal)
                ? normalized
                : "Assets/ModelImports";
        }
    }
}
