using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace TGC.CleanModelImporter
{
    internal static class EpicShadeMaterialConverter
    {
        const string ShaderName = "EpicShade/EpicShade HDRP";
        const string ShaderAssetPath = "Packages/com.pedro.urekatools/Runtime/Shaders/EpicShade HDRP.shadergraph";
        static bool warnedMissingShader;

        static readonly string[] BaseProperties = { "_BaseMap", "_BaseColorMap", "_MainTex", "_DiffuseMap" };
        static readonly string[] NormalProperties = { "_BumpMap", "_NormalMap", "_NormalMapOS" };
        static readonly string[] EmissionProperties = { "_EmissionMap", "_EmissiveColorMap" };
        static readonly string[] PackedProperties = { "_ORMMap" };
        static readonly string[] BaseSuffixes = { "_basecolor", "_base_color", "_albedo", "_diffuse", "_color", "_d" };
        static readonly string[] NormalSuffixes = { "_normalgl", "_normaldx", "_normal", "_n" };
        static readonly string[] MetallicSuffixes = { "_metalness", "_metallic", "_metal", "_m" };
        static readonly string[] RoughnessSuffixes = { "_roughness", "_rough", "_r" };
        static readonly string[] OcclusionSuffixes = { "_ambientocclusion", "_occlusion", "_ao" };
        static readonly string[] EmissionSuffixes = { "_emissive", "_emission", "_emit", "_e" };
        static readonly string[] PackedSuffixes = { "_orm", "_arm" };

        internal static void ConvertModelMaterials(string modelPath, bool buildPackedOrm)
        {
            var shader = FindShader();
            if (shader == null)
            {
                if (!warnedMissingShader)
                {
                    Debug.LogWarning("EpicImport: the EpicShade shader was not found. Materials were extracted but not converted. Reinstall UrekaTools, then reimport the model.");
                    warnedMissingShader = true;
                }
                return;
            }

            var model = AssetDatabase.LoadAssetAtPath<GameObject>(modelPath);
            if (model == null) return;

            var directory = Path.GetDirectoryName(modelPath)?.Replace('\\', '/') ?? "Assets";
            var textureFolder = directory + "/Textures";
            var modelName = Path.GetFileNameWithoutExtension(modelPath);
            var modelTextureFolder = textureFolder + "/" + CleanModelImportUtility.SanitizeFileName(modelName);
            AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
            // New imports keep each model's textures in a dedicated folder. Never
            // fall back from one model-specific folder into another model's maps.
            var scopedTextures = LoadTextures(SearchOption.AllDirectories, modelTextureFolder);
            var texturesAreScoped = scopedTextures.Length > 0;
            // Legacy imports may have extracted textures directly into Textures or
            // placed sidecars beside the FBX. Search only those top-level folders.
            var textures = texturesAreScoped
                ? scopedTextures
                : LoadTextures(SearchOption.TopDirectoryOnly, textureFolder, directory);

            var materials = model.GetComponentsInChildren<Renderer>(true)
                .SelectMany(renderer => renderer.sharedMaterials)
                .Where(material => material != null && !AssetDatabase.IsSubAsset(material))
                .Distinct()
                .ToArray();

            foreach (var material in materials)
                ConvertMaterial(material, shader, textures, modelTextureFolder, modelName,
                    texturesAreScoped, buildPackedOrm);

            AssetDatabase.SaveAssets();
        }

        static Shader FindShader()
        {
            var shader = Shader.Find(ShaderName);
            if (shader != null) return shader;

            // Shader.Find can return null briefly while Shader Graph assets are
            // still registering after a package/domain reload. Loading the known
            // package asset is deterministic and also works on the first import.
            shader = AssetDatabase.LoadAssetAtPath<Shader>(ShaderAssetPath);
            if (shader != null) return shader;

            var guidPath = AssetDatabase.GUIDToAssetPath("b1111111111141118111111111111111");
            return string.IsNullOrEmpty(guidPath) ? null : AssetDatabase.LoadAssetAtPath<Shader>(guidPath);
        }

        static Texture2D[] LoadTextures(SearchOption searchOption, params string[] folders)
        {
            return folders
                .Where(folder => AssetDatabase.IsValidFolder(folder) && Directory.Exists(Path.GetFullPath(folder)))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .SelectMany(folder => Directory.EnumerateFiles(
                        Path.GetFullPath(folder), "*", searchOption)
                    .Where(IsTextureFile)
                    .Select(path => FileUtil.GetProjectRelativePath(path.Replace('\\', '/'))))
                .Where(path => !string.IsNullOrEmpty(path))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Select(path => AssetDatabase.LoadAssetAtPath<Texture2D>(path))
                .Where(texture => texture != null)
                .ToArray();
        }

        internal static bool IsTextureFile(string path)
        {
            var extension = Path.GetExtension(path);
            return extension.Equals(".png", StringComparison.OrdinalIgnoreCase) ||
                   extension.Equals(".tga", StringComparison.OrdinalIgnoreCase) ||
                   extension.Equals(".jpg", StringComparison.OrdinalIgnoreCase) ||
                   extension.Equals(".jpeg", StringComparison.OrdinalIgnoreCase) ||
                   extension.Equals(".tif", StringComparison.OrdinalIgnoreCase) ||
                   extension.Equals(".tiff", StringComparison.OrdinalIgnoreCase) ||
                   extension.Equals(".exr", StringComparison.OrdinalIgnoreCase) ||
                   extension.Equals(".bmp", StringComparison.OrdinalIgnoreCase) ||
                   extension.Equals(".psd", StringComparison.OrdinalIgnoreCase);
        }

        static void ConvertMaterial(Material material, Shader shader, Texture2D[] textures,
            string textureFolder, string modelName, bool texturesAreScoped, bool buildPackedOrm)
        {
            var baseTexture = GetTexture(material, BaseProperties) ??
                FindTexture(textures, material.name, modelName, BaseSuffixes, texturesAreScoped);
            var normalTexture = GetTexture(material, NormalProperties) ??
                FindTexture(textures, material.name, modelName, NormalSuffixes, texturesAreScoped);
            var emissionTexture = GetTexture(material, EmissionProperties) ??
                FindTexture(textures, material.name, modelName, EmissionSuffixes, texturesAreScoped);
            var packedTexture = GetTexture(material, PackedProperties) ??
                FindTexture(textures, material.name, modelName, PackedSuffixes, texturesAreScoped);
            var metallicTexture = FindTexture(textures, material.name, modelName, MetallicSuffixes, texturesAreScoped);
            var roughnessTexture = FindTexture(textures, material.name, modelName, RoughnessSuffixes, texturesAreScoped);
            var occlusionTexture = FindTexture(textures, material.name, modelName, OcclusionSuffixes, texturesAreScoped);

            var baseColor = GetColor(material, new[] { "_BaseColor", "_Color" }, Color.white);
            var emissionColor = GetColor(material, new[] { "_EmissiveColor", "_EmissionColor2", "_EmissionColor" }, Color.black);
            var metallic = GetFloat(material, new[] { "_Metallic" }, 0f);
            var smoothness = GetFloat(material, new[] { "_Smoothness", "_Glossiness", "_GlossMapScale" }, 0.5f);
            var bumpScale = GetFloat(material, new[] { "_NormalScale", "_BumpScale" }, 1f);
            var baseScale = GetTextureScale(material, BaseProperties);
            var baseOffset = GetTextureOffset(material, BaseProperties);

            if (normalTexture != null) ConfigureNormalTexture(normalTexture);
            if (packedTexture != null) ConfigureDataTexture(packedTexture, true);
            if (metallicTexture != null) ConfigureDataTexture(metallicTexture, false);
            if (roughnessTexture != null) ConfigureDataTexture(roughnessTexture, false);
            if (buildPackedOrm && (metallicTexture != null || roughnessTexture != null || occlusionTexture != null))
            {
                EnsureAssetFolderPath(textureFolder);
                // Autodesk Interactive converts roughness to HDRP smoothness as
                // 1 - sqrt(roughness). Encode a missing texture's scalar fallback
                // in the inverse space so it still resolves to the source value.
                var fallbackRoughness = Mathf.Pow(1f - smoothness, 2f);
                packedTexture = BuildOrmTexture(textureFolder, material.name, occlusionTexture,
                    roughnessTexture, metallicTexture, fallbackRoughness, metallic);
            }

            var useSeparateMetallic = !buildPackedOrm && metallicTexture != null;
            var useSeparateRoughness = !buildPackedOrm && roughnessTexture != null;

            AssignShader(material, shader);
            SetTexture(material, "_BaseMap", baseTexture, baseScale, baseOffset);
            SetTexture(material, "_BumpMap", normalTexture, baseScale, baseOffset);
            SetTexture(material, "_EmissionMap", emissionTexture, baseScale, baseOffset);
            SetTexture(material, "_ORMMap", packedTexture, baseScale, baseOffset);
            SetTexture(material, "_MetallicMap", useSeparateMetallic ? metallicTexture : null, baseScale, baseOffset);
            SetTexture(material, "_RoughnessMap", useSeparateRoughness ? roughnessTexture : null, baseScale, baseOffset);
            SetColor(material, "_BaseColor", baseColor);
            SetColor(material, "_EmissionColor2", emissionColor);
            SetFloat(material, "_Metallic", metallic);
            SetFloat(material, "_Smoothness", smoothness);
            SetFloat(material, "_BumpScale", bumpScale);

            SetKeyword(material, "NORMAL_MAP_ON", normalTexture != null);
            SetKeyword(material, "EMISSION_MAP_ON", emissionTexture != null);
            SetKeyword(material, "METALLIC_MAP_ON", packedTexture != null);
            SetKeyword(material, "OCCLUSION_MAP_ON", packedTexture != null);
            SetToggleProperty(material, "_UseSurfaceORM", packedTexture != null);
            SetToggleProperty(material, "_UseMetallicTexture", useSeparateMetallic);
            SetToggleProperty(material, "_UseRoughnessTexture", useSeparateRoughness);
            SetKeyword(material, "METALLIC_TEXTURE_ON", useSeparateMetallic);
            SetKeyword(material, "ROUGHNESS_TEXTURE_ON", useSeparateRoughness);
            material.globalIlluminationFlags = emissionTexture != null || emissionColor.maxColorComponent > 0f
                ? MaterialGlobalIlluminationFlags.BakedEmissive
                : MaterialGlobalIlluminationFlags.EmissiveIsBlack;
            EditorUtility.SetDirty(material);
        }

        static void AssignShader(Material material, Shader shader)
        {
            if (material.shader == shader) return;
            var oldShader = material.shader;

            // Use EpicShade's own migration hook when its Editor assembly is
            // available. This preserves HDRP render-state properties and performs
            // the same transition as selecting the shader in the Inspector.
            var guiType = AppDomain.CurrentDomain.GetAssemblies()
                .Select(assembly => assembly.GetType("UEisBetterGUI", false))
                .FirstOrDefault(type => type != null);
            if (guiType != null && Activator.CreateInstance(guiType) is ShaderGUI shaderGui)
            {
                shaderGui.AssignNewShaderToMaterial(material, oldShader, shader);
                return;
            }

            material.shader = shader;
        }

        static Texture2D BuildOrmTexture(string textureFolder, string materialName, Texture2D occlusion,
            Texture2D roughness, Texture2D metallic, float defaultRoughness, float defaultMetallic)
        {
            var sources = new[] { occlusion, roughness, metallic }.Where(texture => texture != null).ToArray();
            if (sources.Length == 0) return null;

            foreach (var source in sources) ConfigureDataTexture(source, false);
            var decodedOcclusion = DecodeSourceTexture(occlusion);
            var decodedRoughness = DecodeSourceTexture(roughness);
            var decodedMetallic = DecodeSourceTexture(metallic);
            try
            {
                var decodedSources = new[] { decodedOcclusion, decodedRoughness, decodedMetallic }
                    .Where(texture => texture != null).ToArray();
                var width = decodedSources.Max(texture => texture.width);
                var height = decodedSources.Max(texture => texture.height);
                var output = new Texture2D(width, height, TextureFormat.RGBA32, false, true);
                var pixels = new Color[width * height];
                for (var y = 0; y < height; y++)
                for (var x = 0; x < width; x++)
                {
                    var ao = SampleChannel(decodedOcclusion, x, y, width, height, 1f);
                    var rough = SampleChannel(decodedRoughness, x, y, width, height, defaultRoughness);
                    var metal = SampleChannel(decodedMetallic, x, y, width, height, defaultMetallic);
                    pixels[y * width + x] = new Color(ao, rough, metal, 1f);
                }
                output.SetPixels(pixels);
                output.Apply(false, false);

                var fileName = CleanModelImportUtility.SanitizeFileName(materialName) + "_orm.png";
                var outputPath = textureFolder + "/" + fileName;
                File.WriteAllBytes(Path.GetFullPath(outputPath), output.EncodeToPNG());
                UnityEngine.Object.DestroyImmediate(output);
                AssetDatabase.ImportAsset(outputPath, ImportAssetOptions.ForceSynchronousImport | ImportAssetOptions.ForceUpdate);
                var result = AssetDatabase.LoadAssetAtPath<Texture2D>(outputPath);
                ConfigureDataTexture(result, true);
                return result;
            }
            finally
            {
                if (decodedOcclusion != null) UnityEngine.Object.DestroyImmediate(decodedOcclusion);
                if (decodedRoughness != null) UnityEngine.Object.DestroyImmediate(decodedRoughness);
                if (decodedMetallic != null) UnityEngine.Object.DestroyImmediate(decodedMetallic);
            }
        }

        static Texture2D DecodeSourceTexture(Texture2D source)
        {
            if (source == null) return null;
            var path = AssetDatabase.GetAssetPath(source);
            var decoded = new Texture2D(2, 2, TextureFormat.RGBA32, false, true);
            if (ImageConversion.LoadImage(decoded, File.ReadAllBytes(Path.GetFullPath(path)), false)) return decoded;
            UnityEngine.Object.DestroyImmediate(decoded);
            throw new IOException($"EpicImport could not decode data texture '{path}'.");
        }

        static float SampleChannel(Texture2D texture, int x, int y, int outputWidth, int outputHeight, float fallback)
        {
            if (texture == null) return fallback;
            if (texture.width == outputWidth && texture.height == outputHeight)
                return texture.GetPixel(x, y).r;

            var u = (x + 0.5f) / outputWidth;
            var v = (y + 0.5f) / outputHeight;
            return texture.GetPixelBilinear(u, v).r;
        }

        static void ConfigureNormalTexture(Texture2D texture)
        {
            if (texture == null || AssetImporter.GetAtPath(AssetDatabase.GetAssetPath(texture)) is not TextureImporter importer) return;
            if (importer.textureType == TextureImporterType.NormalMap && !importer.sRGBTexture) return;
            importer.textureType = TextureImporterType.NormalMap;
            importer.sRGBTexture = false;
            importer.SaveAndReimport();
        }

        static void ConfigureDataTexture(Texture2D texture, bool generatedOrm)
        {
            if (texture == null || AssetImporter.GetAtPath(AssetDatabase.GetAssetPath(texture)) is not TextureImporter importer) return;
            // Packed channels must remain numerically faithful. Lossy RGB block
            // compression couples the unrelated AO, roughness, and metallic
            // channels and makes the packed map shade differently from the same
            // separate textures. Keep generated ORM uncompressed, but cap it at
            // 2K so the GPU allocation stays at 16 MB instead of 64 MB at 4K.
            var changed = importer.sRGBTexture || importer.isReadable || importer.textureType != TextureImporterType.Default ||
                (generatedOrm && (importer.textureCompression != TextureImporterCompression.Uncompressed ||
                    importer.maxTextureSize > 2048));
            importer.sRGBTexture = false;
            importer.isReadable = false;
            importer.textureType = TextureImporterType.Default;
            if (generatedOrm)
            {
                importer.textureCompression = TextureImporterCompression.Uncompressed;
                importer.maxTextureSize = Mathf.Min(importer.maxTextureSize, 2048);
            }
            if (changed) importer.SaveAndReimport();
        }

        static Texture2D FindTexture(Texture2D[] textures, string materialName, string modelName,
            string[] suffixes, bool allowSingleCandidate)
        {
            var materialStem = NormalizeStem(materialName, Array.Empty<string>());
            var modelStem = NormalizeStem(modelName, Array.Empty<string>());
            var candidates = textures.Where(texture => suffixes.Any(suffix =>
                Path.GetFileNameWithoutExtension(AssetDatabase.GetAssetPath(texture)).EndsWith(suffix, StringComparison.OrdinalIgnoreCase))).ToArray();
            // Material names exported by DCC tools are often unrelated to their
            // texture names, so the owning model stem is an equally valid match.
            var exact = candidates.FirstOrDefault(texture =>
            {
                var textureStem = NormalizeStem(texture.name, suffixes);
                return textureStem == materialStem || textureStem == modelStem;
            });
            return exact != null ? exact : allowSingleCandidate && candidates.Length == 1 ? candidates[0] : null;
        }

        static string NormalizeStem(string value, string[] suffixes)
        {
            var stem = Path.GetFileNameWithoutExtension(value).ToLowerInvariant().Replace(' ', '_');
            foreach (var prefix in new[] { "material_", "texture_", "mat_", "tex_", "sk_", "sm_", "m_", "t_" })
                if (stem.StartsWith(prefix, StringComparison.Ordinal)) { stem = stem.Substring(prefix.Length); break; }
            foreach (var suffix in suffixes.OrderByDescending(item => item.Length))
                if (stem.EndsWith(suffix, StringComparison.Ordinal)) { stem = stem.Substring(0, stem.Length - suffix.Length); break; }
            return stem.Trim('_');
        }

        static void EnsureAssetFolderPath(string folderPath)
        {
            var normalized = folderPath.Replace('\\', '/').TrimEnd('/');
            if (AssetDatabase.IsValidFolder(normalized)) return;
            var parent = Path.GetDirectoryName(normalized)?.Replace('\\', '/') ?? "Assets";
            EnsureAssetFolderPath(parent);
            CleanModelImportUtility.EnsureAssetFolder(parent, Path.GetFileName(normalized));
        }

        static Texture2D GetTexture(Material material, IEnumerable<string> properties)
        {
            foreach (var property in properties)
                if (material.HasProperty(property) && material.GetTexture(property) is Texture2D texture) return texture;
            return null;
        }

        static Color GetColor(Material material, IEnumerable<string> properties, Color fallback)
        {
            foreach (var property in properties)
                if (material.HasProperty(property)) return material.GetColor(property);
            return fallback;
        }

        static float GetFloat(Material material, IEnumerable<string> properties, float fallback)
        {
            foreach (var property in properties)
                if (material.HasProperty(property)) return material.GetFloat(property);
            return fallback;
        }

        static Vector2 GetTextureScale(Material material, IEnumerable<string> properties)
        {
            foreach (var property in properties)
                if (material.HasProperty(property)) return material.GetTextureScale(property);
            return Vector2.one;
        }

        static Vector2 GetTextureOffset(Material material, IEnumerable<string> properties)
        {
            foreach (var property in properties)
                if (material.HasProperty(property)) return material.GetTextureOffset(property);
            return Vector2.zero;
        }

        static void SetTexture(Material material, string property, Texture texture, Vector2 scale, Vector2 offset)
        {
            if (!material.HasProperty(property)) return;
            material.SetTexture(property, texture);
            material.SetTextureScale(property, scale);
            material.SetTextureOffset(property, offset);
        }

        static void SetColor(Material material, string property, Color value)
        {
            if (material.HasProperty(property)) material.SetColor(property, value);
        }

        static void SetFloat(Material material, string property, float value)
        {
            if (material.HasProperty(property)) material.SetFloat(property, value);
        }

        static void SetKeyword(Material material, string keyword, bool enabled)
        {
            if (enabled) material.EnableKeyword(keyword); else material.DisableKeyword(keyword);
        }

        static void SetToggleProperty(Material material, string propertyName, bool enabled)
        {
            if (material.HasProperty(propertyName))
                material.SetFloat(propertyName, enabled ? 1f : 0f);
        }
    }
}
