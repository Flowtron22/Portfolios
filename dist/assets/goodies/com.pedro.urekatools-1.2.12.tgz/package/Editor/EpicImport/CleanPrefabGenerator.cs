using System.IO;
using UnityEditor;
using UnityEngine;

namespace TGC.CleanModelImporter
{
    internal static class CleanPrefabGenerator
    {
        internal static string Generate(string modelPath, CleanModelImporterSettings settings)
        {
            var model = AssetDatabase.LoadAssetAtPath<GameObject>(modelPath);
            if (model == null)
            {
                if (modelPath.EndsWith(".gltf") || modelPath.EndsWith(".glb"))
                    Debug.LogWarning($"EpicImport: '{modelPath}' needs a glTF importer that exposes a GameObject asset.");
                return null;
            }

            var directory = Path.GetDirectoryName(modelPath)?.Replace('\\', '/') ?? "Assets";
            var prefabFolder = CleanModelImportUtility.EnsureAssetFolder(directory, "CleanPrefabs");
            var prefabPath = prefabFolder + "/" + Path.GetFileNameWithoutExtension(modelPath) + "_Clean.prefab";

            var root = new GameObject(Path.GetFileNameWithoutExtension(modelPath));
            try
            {
                root.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
                root.transform.localScale = Vector3.one;

                var instance = (GameObject)PrefabUtility.InstantiatePrefab(model);
                if (instance == null) instance = Object.Instantiate(model);
                instance.name = model.name;
                instance.transform.SetParent(root.transform, false);
                instance.transform.localPosition = Vector3.zero;
                instance.transform.localRotation = Quaternion.identity;
                instance.transform.localScale = Vector3.one;

                ApplyPivot(root, instance, settings);
                PrefabUtility.SaveAsPrefabAsset(root, prefabPath);
                return prefabPath;
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }

        static void ApplyPivot(GameObject root, GameObject instance, CleanModelImporterSettings settings)
        {
            Vector3 pivotWorld;
            switch (settings.PivotMode)
            {
                case CleanPivotMode.Marker:
                    var marker = CleanModelImportUtility.FindDeepChild(instance.transform, settings.PivotMarkerName);
                    if (marker == null)
                    {
                        Debug.LogWarning($"EpicImport: marker '{settings.PivotMarkerName}' was not found in '{instance.name}'. Source origin was used.", instance);
                        return;
                    }
                    pivotWorld = marker.position;
                    if (settings.HidePivotMarker) marker.gameObject.SetActive(false);
                    break;
                case CleanPivotMode.BoundsCenter:
                    if (!CleanModelImportUtility.TryGetCombinedBounds(instance, out var centerBounds)) return;
                    pivotWorld = centerBounds.center;
                    break;
                case CleanPivotMode.BoundsBottomCenter:
                    if (!CleanModelImportUtility.TryGetCombinedBounds(instance, out var bottomBounds)) return;
                    pivotWorld = new Vector3(bottomBounds.center.x, bottomBounds.min.y, bottomBounds.center.z);
                    break;
                default:
                    return;
            }

            var localPivot = root.transform.InverseTransformPoint(pivotWorld);
            instance.transform.localPosition -= localPivot;
        }
    }
}
