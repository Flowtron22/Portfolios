using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace TGC.CleanModelImporter
{
    internal sealed class EpicImportWindow : EditorWindow
    {
        [MenuItem("UrekaTools/EpicImport/Open Importer", false, 1)]
        static void Open() => GetWindow<EpicImportWindow>("EpicImport");

        [MenuItem("UrekaTools/EpicImport/Rebuild Selected Model Materials", false, 2)]
        static void RebuildSelectedModelMaterials()
        {
            var modelPaths = SelectedModelPaths().Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
            var settings = CleanModelImporterSettings.instance;
            foreach (var modelPath in modelPaths)
                EpicShadeMaterialConverter.ConvertModelMaterials(modelPath, settings.BuildPackedOrm);

            if (modelPaths.Length > 0)
                Debug.Log($"EpicImport rebuilt EpicShade materials for {modelPaths.Length} selected model(s).");
        }

        [MenuItem("UrekaTools/EpicImport/Rebuild Selected Model Materials", true)]
        static bool CanRebuildSelectedModelMaterials() => SelectedModelPaths().Any();

        [MenuItem("Assets/EpicImport/Enable and Reimport", true)]
        static bool CanEnableSelected() => SelectedModelPaths().Any();

        [MenuItem("Assets/EpicImport/Enable and Reimport")]
        static void EnableSelected()
        {
            foreach (var path in SelectedModelPaths())
            {
                var importer = AssetImporter.GetAtPath(path);
                importer.userData = CleanModelImportUtility.SetFlag(importer.userData, CleanModelImportUtility.EnabledFlag, true);
                importer.userData = CleanModelImportUtility.SetFlag(importer.userData, CleanModelImportUtility.DisabledFlag, false);
                importer.userData = CleanModelImportUtility.SetFlag(importer.userData, CleanModelImportUtility.ExtractedFlag, false);
                importer.SaveAndReimport();
            }
        }

        [MenuItem("Assets/EpicImport/Disable", true)]
        static bool CanDisableSelected() => SelectedModelPaths().Any();

        [MenuItem("Assets/EpicImport/Disable")]
        static void DisableSelected()
        {
            foreach (var path in SelectedModelPaths())
            {
                var importer = AssetImporter.GetAtPath(path);
                importer.userData = CleanModelImportUtility.SetFlag(importer.userData, CleanModelImportUtility.EnabledFlag, false);
                importer.userData = CleanModelImportUtility.SetFlag(importer.userData, CleanModelImportUtility.DisabledFlag, true);
                importer.SaveAndReimport();
            }
        }

        [MenuItem("Assets/EpicImport/Rebuild Clean Prefab", true)]
        static bool CanRebuildSelected() => SelectedModelPaths().Any();

        [MenuItem("Assets/EpicImport/Rebuild Clean Prefab")]
        static void RebuildSelected()
        {
            foreach (var path in SelectedModelPaths())
                CleanModelImportQueue.ProcessOne(path, false);
        }

        static string[] SelectedModelPaths() => Selection.objects
            .Select(AssetDatabase.GetAssetPath)
            .Where(CleanModelImportUtility.IsSupportedModelPath)
            .Distinct()
            .ToArray();

        void OnGUI()
        {
            var settings = CleanModelImporterSettings.instance;
            EditorGUILayout.HelpBox(
                "FBX/OBJ: axis and scale settings are applied before Unity imports the model. A generated prefab supplies a guaranteed identity root. GLB/glTF prefab generation works when another installed importer exposes a GameObject asset.",
                MessageType.Info);

            EditorGUI.BeginChangeCheck();
            settings.Enabled = EditorGUILayout.Toggle("Enabled", settings.Enabled);
            settings.WatchedFolder = EditorGUILayout.TextField("Watched Folder", settings.WatchedFolder);
            EditorGUILayout.Space();
            settings.BakeAxisConversion = EditorGUILayout.Toggle("Bake Axis Conversion", settings.BakeAxisConversion);
            settings.UseFileScale = EditorGUILayout.Toggle("Use File Scale", settings.UseFileScale);
            settings.PreserveHierarchy = EditorGUILayout.Toggle("Preserve Hierarchy", settings.PreserveHierarchy);
            settings.ImportMaterials = EditorGUILayout.Toggle("Import Materials", settings.ImportMaterials);
            settings.AutoExtractTextures = EditorGUILayout.Toggle("Extract Textures", settings.AutoExtractTextures);
            settings.CopySidecarTextures = EditorGUILayout.Toggle("Copy Sidecar Textures", settings.CopySidecarTextures);
            settings.AutoExtractMaterials = EditorGUILayout.Toggle("Extract Materials", settings.AutoExtractMaterials);
            settings.ApplyEpicShadeShader = EditorGUILayout.Toggle("Use EpicShade Shader", settings.ApplyEpicShadeShader);
            if (settings.ApplyEpicShadeShader)
                settings.BuildPackedOrm = EditorGUILayout.Toggle("Build Packed ORM", settings.BuildPackedOrm);
            EditorGUILayout.Space();
            settings.GenerateCleanPrefab = EditorGUILayout.Toggle("Generate Clean Prefab", settings.GenerateCleanPrefab);
            settings.PivotMode = (CleanPivotMode)EditorGUILayout.EnumPopup("Prefab Pivot", settings.PivotMode);
            if (settings.PivotMode == CleanPivotMode.Marker)
            {
                settings.PivotMarkerName = EditorGUILayout.TextField("Marker Name", settings.PivotMarkerName);
                settings.HidePivotMarker = EditorGUILayout.Toggle("Hide Marker", settings.HidePivotMarker);
            }

            if (EditorGUI.EndChangeCheck()) settings.SaveSettings();

            EditorGUILayout.Space();
            EditorGUILayout.HelpBox(
                "For an exact 3ds Max pivot, export a helper/dummy named __PIVOT__ at the desired pivot and select Marker mode. OBJ files do not contain pivot or hierarchy metadata.",
                MessageType.Warning);

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Create / Reveal Watched Folder"))
                    RevealWatchedFolder(settings.WatchedFolder);
                if (GUILayout.Button("Import Model..."))
                    ImportModel(settings);
            }
            if (GUILayout.Button("Repair / Reprocess All Managed Models"))
            {
                var count = CleanModelImportQueue.EnqueueAllManagedModels();
                ShowNotification(new GUIContent($"Queued {count} model(s)"));
            }
        }

        static string CreateWatchedFolder(string folder)
        {
            folder = CleanModelImporterSettings.NormalizeFolder(folder);
            var segments = folder.Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
            if (segments.Length == 0 || segments[0] != "Assets")
                throw new InvalidOperationException("The watched folder must be inside Assets.");

            var current = segments[0];
            for (var index = 1; index < segments.Length; index++)
            {
                var next = current + "/" + segments[index];
                if (!AssetDatabase.IsValidFolder(next))
                {
                    var guid = AssetDatabase.CreateFolder(current, segments[index]);
                    if (string.IsNullOrEmpty(guid))
                        throw new IOException($"Unity could not create '{next}'.");
                }
                current = next;
            }
            return current;
        }

        void RevealWatchedFolder(string folder)
        {
            try
            {
                var path = CreateWatchedFolder(folder);
                AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
                var folderAsset = AssetDatabase.LoadAssetAtPath<DefaultAsset>(path);
                Selection.activeObject = folderAsset;
                if (folderAsset != null) EditorGUIUtility.PingObject(folderAsset);
                ShowNotification(new GUIContent($"Ready: {path}"));
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                EditorUtility.DisplayDialog("EpicImport", exception.Message, "OK");
            }
        }

        void ImportModel(CleanModelImporterSettings settings)
        {
            var source = EditorUtility.OpenFilePanelWithFilters(
                "Import Model",
                string.Empty,
                new[] { "Model files", "fbx,obj,glb,gltf", "FBX", "fbx", "OBJ", "obj", "glTF / GLB", "gltf,glb" });
            if (string.IsNullOrEmpty(source)) return;

            try
            {
                var destinationFolder = CreateWatchedFolder(settings.WatchedFolder);
                var destination = AssetDatabase.GenerateUniqueAssetPath(destinationFolder + "/" + Path.GetFileName(source));
                File.Copy(source, Path.GetFullPath(destination), false);
                var copiedTextures = settings.CopySidecarTextures
                    ? CopySidecarTextures(source, destinationFolder, Path.GetFileNameWithoutExtension(destination))
                    : 0;
                AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
                AssetDatabase.ImportAsset(destination, ImportAssetOptions.ForceSynchronousImport | ImportAssetOptions.ForceUpdate);
                var imported = AssetDatabase.LoadMainAssetAtPath(destination);
                var extension = Path.GetExtension(destination);
                if ((extension.Equals(".gltf", StringComparison.OrdinalIgnoreCase) ||
                     extension.Equals(".glb", StringComparison.OrdinalIgnoreCase)) &&
                    imported is not GameObject)
                {
                    EditorUtility.DisplayDialog(
                        "EpicImport: glTF importer required",
                        "Unity does not include a built-in GLB/glTF importer. Install a compatible glTF importer, then reimport this file. FBX and OBJ work without an additional model-import package.",
                        "OK");
                }
                Selection.activeObject = imported;
                if (imported != null) EditorGUIUtility.PingObject(imported);
                ShowNotification(new GUIContent(
                    copiedTextures > 0
                        ? $"Imported model + {copiedTextures} texture(s)"
                        : $"Imported: {Path.GetFileName(destination)}"));
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                EditorUtility.DisplayDialog("EpicImport", exception.Message, "OK");
            }
        }

        static int CopySidecarTextures(string sourceModel, string destinationFolder, string modelName)
        {
            var sourceFolder = Path.GetDirectoryName(sourceModel);
            if (string.IsNullOrEmpty(sourceFolder) || !Directory.Exists(sourceFolder)) return 0;

            var textureFolder = CreateWatchedFolder(
                destinationFolder + "/Textures/" + CleanModelImportUtility.SanitizeFileName(modelName));
            var count = 0;
            foreach (var sourceTexture in Directory.EnumerateFiles(sourceFolder, "*", SearchOption.TopDirectoryOnly)
                         .Where(EpicShadeMaterialConverter.IsTextureFile))
            {
                var destination = textureFolder + "/" + Path.GetFileName(sourceTexture);
                var destinationFullPath = Path.GetFullPath(destination);
                if (Path.GetFullPath(sourceTexture).Equals(destinationFullPath, StringComparison.OrdinalIgnoreCase))
                    continue;
                if (File.Exists(destinationFullPath))
                    destination = AssetDatabase.GenerateUniqueAssetPath(destination);
                File.Copy(sourceTexture, Path.GetFullPath(destination), false);
                count++;
            }
            return count;
        }
    }
}
