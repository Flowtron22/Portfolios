using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace TGC.CleanModelImporter
{
    internal static class CleanModelImportUtility
    {
        internal const string EnabledFlag = "TGC_CLEAN_MODEL_IMPORTER";
        internal const string DisabledFlag = "TGC_CMI_DISABLED";
        internal const string ExtractedFlag = "TGC_CMI_EXTRACTED";
        static readonly string[] NativeExtensions = { ".fbx", ".obj" };
        static readonly string[] OptionalExtensions = { ".gltf", ".glb" };

        internal static bool IsSupportedModelPath(string path)
        {
            var extension = Path.GetExtension(path);
            return NativeExtensions.Concat(OptionalExtensions).Any(value =>
                extension.Equals(value, StringComparison.OrdinalIgnoreCase));
        }

        internal static bool IsNativeModelPath(string path)
        {
            var extension = Path.GetExtension(path);
            return NativeExtensions.Any(value => extension.Equals(value, StringComparison.OrdinalIgnoreCase));
        }

        internal static bool HasFlag(string userData, string flag) =>
            !string.IsNullOrEmpty(userData) && userData.Split(';').Any(value => value.Equals(flag, StringComparison.Ordinal));

        internal static string SetFlag(string userData, string flag, bool enabled)
        {
            var flags = new HashSet<string>((userData ?? string.Empty).Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries));
            if (enabled) flags.Add(flag); else flags.Remove(flag);
            return string.Join(";", flags);
        }

        internal static string EnsureAssetFolder(string parent, string name)
        {
            parent = parent.Replace('\\', '/').TrimEnd('/');
            var path = parent + "/" + name;
            if (!AssetDatabase.IsValidFolder(path))
                AssetDatabase.CreateFolder(parent, name);
            return path;
        }

        internal static string SanitizeFileName(string value)
        {
            foreach (var invalid in Path.GetInvalidFileNameChars())
                value = value.Replace(invalid, '_');
            return string.IsNullOrWhiteSpace(value) ? "Material" : value;
        }

        internal static Transform FindDeepChild(Transform root, string childName)
        {
            if (root.name.Equals(childName, StringComparison.OrdinalIgnoreCase)) return root;
            foreach (Transform child in root)
            {
                var result = FindDeepChild(child, childName);
                if (result != null) return result;
            }
            return null;
        }

        internal static bool TryGetCombinedBounds(GameObject root, out Bounds bounds)
        {
            var renderers = root.GetComponentsInChildren<Renderer>(true);
            if (renderers.Length == 0)
            {
                bounds = default;
                return false;
            }

            bounds = renderers[0].bounds;
            for (var index = 1; index < renderers.Length; index++)
                bounds.Encapsulate(renderers[index].bounds);
            return true;
        }
    }
}
