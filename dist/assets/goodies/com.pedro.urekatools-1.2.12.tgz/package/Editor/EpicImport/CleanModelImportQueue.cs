using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace TGC.CleanModelImporter
{
    internal static class CleanModelImportQueue
    {
        static readonly HashSet<string> Pending = new(StringComparer.OrdinalIgnoreCase);
        static bool scheduled;
        static bool processing;

        internal static int EnqueueAllManagedModels()
        {
            var settings = CleanModelImporterSettings.instance;
            var folder = settings.WatchedFolder;
            if (!settings.Enabled || !AssetDatabase.IsValidFolder(folder)) return 0;

            var count = 0;
            foreach (var guid in AssetDatabase.FindAssets("t:GameObject", new[] { folder }))
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                if (CleanModelImportUtility.IsSupportedModelPath(path) && settings.ShouldProcess(path))
                {
                    Enqueue(path);
                    count++;
                }
            }
            return count;
        }

        internal static void Enqueue(string assetPath)
        {
            if (processing || !CleanModelImportUtility.IsSupportedModelPath(assetPath)) return;
            Pending.Add(assetPath);
            if (scheduled) return;
            scheduled = true;
            EditorApplication.delayCall += Process;
        }

        static void Process()
        {
            scheduled = false;
            if (processing) return;
            processing = true;
            try
            {
                foreach (var path in Pending.ToArray())
                {
                    Pending.Remove(path);
                    if (!CleanModelImporterSettings.instance.ShouldProcess(path)) continue;
                    ProcessOne(path);
                }
            }
            finally
            {
                processing = false;
            }
        }

        internal static void ProcessOne(string assetPath, bool forceExtraction = false)
        {
            var settings = CleanModelImporterSettings.instance;
            if (CleanModelImportUtility.IsNativeModelPath(assetPath))
                ExtractEmbeddedAssets(assetPath, settings, forceExtraction);

            if (settings.ApplyEpicShadeShader)
                EpicShadeMaterialConverter.ConvertModelMaterials(assetPath, settings.BuildPackedOrm);

            if (settings.GenerateCleanPrefab)
                CleanPrefabGenerator.Generate(assetPath, settings);
        }

        static void ExtractEmbeddedAssets(string assetPath, CleanModelImporterSettings settings, bool force)
        {
            if (AssetImporter.GetAtPath(assetPath) is not ModelImporter importer) return;
            if (!force && CleanModelImportUtility.HasFlag(importer.userData, CleanModelImportUtility.ExtractedFlag)) return;

            var parent = Path.GetDirectoryName(assetPath)?.Replace('\\', '/') ?? "Assets";
            var changed = false;

            if (settings.AutoExtractTextures)
            {
                var textureRoot = CleanModelImportUtility.EnsureAssetFolder(parent, "Textures");
                var modelName = CleanModelImportUtility.SanitizeFileName(Path.GetFileNameWithoutExtension(assetPath));
                var textureFolder = CleanModelImportUtility.EnsureAssetFolder(textureRoot, modelName);
                importer.ExtractTextures(textureFolder);
                changed = true;
            }

            if (settings.AutoExtractMaterials)
            {
                var materialFolder = CleanModelImportUtility.EnsureAssetFolder(parent, "Materials");
                var materials = AssetDatabase.LoadAllAssetsAtPath(assetPath).OfType<Material>().ToArray();
                foreach (var material in materials)
                {
                    if (!AssetDatabase.IsSubAsset(material)) continue;
                    var destination = AssetDatabase.GenerateUniqueAssetPath(
                        materialFolder + "/" + CleanModelImportUtility.SanitizeFileName(material.name) + ".mat");
                    var error = AssetDatabase.ExtractAsset(material, destination);
                    if (string.IsNullOrEmpty(error)) changed = true;
                    else Debug.LogWarning($"EpicImport could not extract '{material.name}': {error}", material);
                }
            }

            importer = AssetImporter.GetAtPath(assetPath) as ModelImporter;
            if (importer == null) return;
            importer.userData = CleanModelImportUtility.SetFlag(importer.userData, CleanModelImportUtility.ExtractedFlag, true);
            AssetDatabase.WriteImportSettingsIfDirty(assetPath);
            if (changed) AssetDatabase.ImportAsset(assetPath, ImportAssetOptions.ForceUpdate);
        }
    }
}
