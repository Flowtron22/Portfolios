//------------------------------------
//              UEisBetter
// Local derivative of OmniShade PBR for licensed project use.
// Original work Copyright© 2025 OmniShade.
//------------------------------------

/**
 * This class contains shader constants and utility functions.
 **/
public static class UEisBetter {
	public const string NAME = "EpicShade";
	public const string VERSION = "1.1.0";
}
