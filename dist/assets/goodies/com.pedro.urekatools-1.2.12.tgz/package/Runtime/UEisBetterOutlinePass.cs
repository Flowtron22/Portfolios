//------------------------------------
//              EpicShade
// Material-controlled HDRP geometry outline.
//------------------------------------

#if UNITY_PIPELINE_HDRP
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.Rendering;
using UnityEngine.Rendering.HighDefinition;
using UnityEngine.SceneManagement;

[Serializable]
public sealed class UEisBetterOutlinePass : CustomPass
{
	public const string EnabledProperty = "_UEisBetterOutlineEnabled";
	public const string ColorProperty = "_UEisBetterOutlineColor";
	public const string WidthProperty = "_UEisBetterOutlineWidth";
	public const string OpacityProperty = "_UEisBetterOutlineOpacity";
	public const string BiasProperty = "_UEisBetterOutlineBias";
	public const string ContrastProperty = "_UEisBetterOutlineContrast";
	public const string ExposureCompensationProperty = "_UEisBetterOutlineExposureCompensation";
	const string PlantSwayKeyword = "PLANT_SWAY_ON";
	const string PlantSwayEnabledProperty = "_UEisBetterPlantSwayEnabled";
	const string PlantSwayAmountProperty = "Vector1_6c19bc30b5f24c9981a0b4342363bddd";
	const string PlantSwaySpeedProperty = "Vector1_1d1f6529f5744d9ab4b71e074ea7327c";
	const string PlantSwayBaseHeightProperty = "Vector1_b16b91113fe247d98d96cb9c268c473d";
	const string PlantSwayPhaseVariationProperty = "Vector1_fa9c479eb4544cceae07165a8a72b81b";
	const string PlantSwayAsLeafProperty = "Boolean_4da072f3cb7244e0b71bb01fe70a94e0";
	const string BaseMapProperty = "_BaseMap";
	const string BaseColorProperty = "_BaseColor";
	const string IgnoreBaseMapAlphaProperty = "Boolean_FB0425B4";
	const string CutoutKeyword = "CUTOUT_ON";
	const string AlphaClipEnabledProperty = "_UEisBetterAlphaClipEnabled";
	const string IgnoreAlphaProperty = "_UEisBetterIgnoreBaseMapAlpha";
	const string BaseColorAlphaProperty = "_UEisBetterBaseColorAlpha";
	const string AlphaClipThresholdProperty = "_UEisBetterAlphaClipThreshold";

	const string OutlineShaderName = "Hidden/EpicShade/HDRP Outline";
	const int SilhouetteMaskPass = 0;
	const int OutlinePass = 1;
	static readonly int OutlineMaskTextureId = Shader.PropertyToID("_UEisBetterOutlineMaskTexture");

	static int rendererCacheVersion;

	readonly Dictionary<Material, Material> outlineMaterials = new();
	readonly List<OutlineDrawRequest> drawRequests = new();
	readonly HashSet<Material> activeMaterials = new();
	readonly List<Material> staleMaterials = new();
	Renderer[] renderers = Array.Empty<Renderer>();
	Shader outlineShader;
	RTHandle silhouetteMask;
	int observedRendererCacheVersion = -1;

	public static void InvalidateRendererCache()
	{
		rendererCacheVersion++;
	}

	protected override void Setup(ScriptableRenderContext renderContext, CommandBuffer cmd)
	{
		name = "EpicShade Material Outlines";
		// Loading from Resources creates a serialized package reference, so Unity keeps
		// the hidden support shader in player builds without project-specific graphics settings.
		outlineShader = Resources.Load<Shader>("EpicShade HDRP Outline");
		if (outlineShader == null)
			outlineShader = Shader.Find(OutlineShaderName);
		if (outlineShader == null)
		{
			Debug.LogError(
				$"[EpicShade] Required outline shader '{OutlineShaderName}' was not found. " +
				"Reinstall the package and confirm its Runtime/Resources folder is intact.");
			return;
		}
		RefreshRenderers();
	}

	protected override void Execute(CustomPassContext ctx)
	{
		Camera camera = ctx.hdCamera.camera;
		if (outlineShader == null || camera == null ||
			(camera.cameraType != CameraType.Game && camera.cameraType != CameraType.SceneView))
			return;

		if (observedRendererCacheVersion != rendererCacheVersion)
			RefreshRenderers();
		if (renderers.Length == 0)
			return;

		drawRequests.Clear();
		Plane[] frustumPlanes = GeometryUtility.CalculateFrustumPlanes(camera);
		for (int rendererIndex = 0; rendererIndex < renderers.Length; rendererIndex++)
		{
			Renderer renderer = renderers[rendererIndex];
			if (renderer == null || !renderer.enabled || renderer.forceRenderingOff ||
				!renderer.gameObject.activeInHierarchy ||
				(camera.cullingMask & (1 << renderer.gameObject.layer)) == 0)
				continue;

			Material[] sourceMaterials = renderer.sharedMaterials;
			Bounds expandedBounds = renderer.bounds;
			expandedBounds.Expand(GetBoundsPadding(sourceMaterials, expandedBounds) * 2f);
			if (!GeometryUtility.TestPlanesAABB(frustumPlanes, expandedBounds))
				continue;

			int subMeshCount = GetSubMeshCount(renderer);
			int drawCount = Mathf.Min(sourceMaterials.Length, subMeshCount);
			for (int subMeshIndex = 0; subMeshIndex < drawCount; subMeshIndex++)
			{
				Material sourceMaterial = sourceMaterials[subMeshIndex];
				if (!IsOutlineEnabled(sourceMaterial) ||
					(sourceMaterial.HasProperty(OpacityProperty) &&
					sourceMaterial.GetFloat(OpacityProperty) <= 0.0001f))
					continue;

				Material outlineMaterial = GetOutlineMaterial(sourceMaterial);
				if (outlineMaterial != null)
					drawRequests.Add(new OutlineDrawRequest(renderer, outlineMaterial, subMeshIndex));
			}
		}

		if (drawRequests.Count == 0)
			return;
		EnsureSilhouetteMask();
		if (silhouetteMask == null)
			return;

		// Use a private mask so this pass cannot erase or overwrite HDRP's shared custom
		// color buffer, which may be in use by unrelated custom passes.
		CoreUtils.SetRenderTarget(
			ctx.cmd,
			silhouetteMask,
			ClearFlag.Color,
			Color.clear);
		DrawRequests(ctx.cmd, SilhouetteMaskPass);
		ctx.cmd.SetGlobalTexture(OutlineMaskTextureId, silhouetteMask);

		CoreUtils.SetRenderTarget(
			ctx.cmd,
			ctx.cameraColorBuffer,
			ctx.cameraDepthBuffer,
			ClearFlag.None);
		DrawRequests(ctx.cmd, OutlinePass);
	}

	void DrawRequests(CommandBuffer cmd, int shaderPass)
	{
		for (int i = 0; i < drawRequests.Count; i++)
		{
			OutlineDrawRequest request = drawRequests[i];
			cmd.DrawRenderer(request.renderer, request.material, request.subMeshIndex, shaderPass);
		}
	}

	void EnsureSilhouetteMask()
	{
		if (silhouetteMask != null)
			return;
		silhouetteMask = RTHandles.Alloc(
			Vector2.one,
			TextureXR.slices,
			dimension: TextureXR.dimension,
			colorFormat: GraphicsFormat.R8_UNorm,
			filterMode: FilterMode.Point,
			useDynamicScale: true,
			name: "EpicShade Outline Silhouette Mask");
	}

	protected override void Cleanup()
	{
		foreach (Material material in outlineMaterials.Values)
			CoreUtils.Destroy(material);
		outlineMaterials.Clear();
		activeMaterials.Clear();
		staleMaterials.Clear();
		silhouetteMask?.Release();
		silhouetteMask = null;
		renderers = Array.Empty<Renderer>();
		drawRequests.Clear();
	}

	void RefreshRenderers()
	{
		// Include inactive objects once so enabling an existing renderer does not
		// require another scene-wide search. Cache invalidation is event-driven.
		Renderer[] allRenderers = UnityEngine.Object.FindObjectsByType<Renderer>(
			FindObjectsInactive.Include,
			FindObjectsSortMode.None);
		var outlinedRenderers = new List<Renderer>();
		activeMaterials.Clear();
		foreach (Renderer renderer in allRenderers)
		{
			if (renderer == null || !renderer.gameObject.scene.IsValid())
				continue;

			Material[] materials = renderer.sharedMaterials;
			bool rendererHasOutline = false;
			for (int i = 0; i < materials.Length; i++)
			{
				if (!IsOutlineEnabled(materials[i]))
					continue;
				activeMaterials.Add(materials[i]);
				rendererHasOutline = true;
			}
			if (rendererHasOutline)
				outlinedRenderers.Add(renderer);
		}

		staleMaterials.Clear();
		foreach (KeyValuePair<Material, Material> cached in outlineMaterials)
		{
			if (cached.Key == null || !activeMaterials.Contains(cached.Key))
				staleMaterials.Add(cached.Key);
		}
		foreach (Material staleSource in staleMaterials)
		{
			CoreUtils.Destroy(outlineMaterials[staleSource]);
			outlineMaterials.Remove(staleSource);
		}

		renderers = outlinedRenderers.ToArray();
		if (renderers.Length == 0 && silhouetteMask != null)
		{
			silhouetteMask.Release();
			silhouetteMask = null;
		}
		observedRendererCacheVersion = rendererCacheVersion;
	}

	Material GetOutlineMaterial(Material sourceMaterial)
	{
		if (!outlineMaterials.TryGetValue(sourceMaterial, out Material outlineMaterial) || outlineMaterial == null)
		{
			outlineMaterial = CoreUtils.CreateEngineMaterial(outlineShader);
			outlineMaterial.name = sourceMaterial.name + " (EpicShade Outline Runtime)";
			outlineMaterial.hideFlags = HideFlags.HideAndDontSave;
			outlineMaterials[sourceMaterial] = outlineMaterial;
		}

		outlineMaterial.SetColor(ColorProperty, sourceMaterial.GetColor(ColorProperty));
		outlineMaterial.SetFloat(WidthProperty, Mathf.Max(0f, sourceMaterial.GetFloat(WidthProperty)));
		outlineMaterial.SetFloat(OpacityProperty, Mathf.Clamp01(sourceMaterial.GetFloat(OpacityProperty)));
		outlineMaterial.SetFloat(BiasProperty, Mathf.Clamp(sourceMaterial.GetFloat(BiasProperty), -1f, 1f));
		outlineMaterial.SetFloat(ContrastProperty, Mathf.Max(0.01f, sourceMaterial.GetFloat(ContrastProperty)));
		outlineMaterial.SetFloat(
			ExposureCompensationProperty,
			sourceMaterial.GetFloat(ExposureCompensationProperty) > 0.5f ? 1f : 0f);
		outlineMaterial.SetFloat(PlantSwayEnabledProperty,
			sourceMaterial.IsKeywordEnabled(PlantSwayKeyword) ? 1f : 0f);
		CopyFloatProperty(sourceMaterial, outlineMaterial, PlantSwayAmountProperty);
		CopyFloatProperty(sourceMaterial, outlineMaterial, PlantSwaySpeedProperty);
		CopyFloatProperty(sourceMaterial, outlineMaterial, PlantSwayBaseHeightProperty);
		CopyFloatProperty(sourceMaterial, outlineMaterial, PlantSwayPhaseVariationProperty);
		CopyFloatProperty(sourceMaterial, outlineMaterial, PlantSwayAsLeafProperty);

		bool alphaClip = sourceMaterial.IsKeywordEnabled(CutoutKeyword);
		outlineMaterial.SetFloat(AlphaClipEnabledProperty, alphaClip ? 1f : 0f);
		outlineMaterial.SetFloat(IgnoreAlphaProperty,
			sourceMaterial.HasProperty(IgnoreBaseMapAlphaProperty) &&
			sourceMaterial.GetFloat(IgnoreBaseMapAlphaProperty) > 0.5f ? 1f : 0f);
		outlineMaterial.SetFloat(BaseColorAlphaProperty,
			sourceMaterial.HasProperty(BaseColorProperty) ? sourceMaterial.GetColor(BaseColorProperty).a : 1f);
		outlineMaterial.SetFloat(AlphaClipThresholdProperty,
			sourceMaterial.HasProperty("_AlphaCutoff")
				? Mathf.Clamp01(sourceMaterial.GetFloat("_AlphaCutoff"))
				: 0.5f);
		if (sourceMaterial.HasProperty(BaseMapProperty))
		{
			outlineMaterial.SetTexture(BaseMapProperty, sourceMaterial.GetTexture(BaseMapProperty));
			outlineMaterial.SetTextureScale(BaseMapProperty, sourceMaterial.GetTextureScale(BaseMapProperty));
			outlineMaterial.SetTextureOffset(BaseMapProperty, sourceMaterial.GetTextureOffset(BaseMapProperty));
		}
		return outlineMaterial;
	}

	static float GetBoundsPadding(Material[] materials, Bounds bounds)
	{
		float padding = 0f;
		for (int i = 0; i < materials.Length; i++)
		{
			Material material = materials[i];
			if (!IsOutlineEnabled(material))
				continue;

			if (material.HasProperty(WidthProperty))
			{
				float width = Mathf.Max(0f, material.GetFloat(WidthProperty));
				float bias = material.HasProperty(BiasProperty)
					? Mathf.Clamp(material.GetFloat(BiasProperty), -1f, 1f)
					: 0f;
				padding = Mathf.Max(padding, width * (1f + bias));
			}

			if (material.IsKeywordEnabled(PlantSwayKeyword) && material.HasProperty(PlantSwayAmountProperty))
			{
				float swayAmount = Mathf.Abs(material.GetFloat(PlantSwayAmountProperty));
				float baseHeight = material.HasProperty(PlantSwayBaseHeightProperty)
					? Mathf.Abs(material.GetFloat(PlantSwayBaseHeightProperty))
					: 0f;
				padding = Mathf.Max(padding,
					swayAmount * (bounds.size.y + baseHeight + 0.15f) * 1.5f);
			}
		}

		return padding;
	}

	static void CopyFloatProperty(Material source, Material destination, string propertyName)
	{
		if (source.HasProperty(propertyName) && destination.HasProperty(propertyName))
			destination.SetFloat(propertyName, source.GetFloat(propertyName));
	}

	static bool IsOutlineEnabled(Material material)
	{
		return material != null &&
			material.shader != null &&
			material.shader.name.Contains(UEisBetter.NAME) &&
			material.HasProperty(EnabledProperty) &&
			material.GetFloat(EnabledProperty) > 0.5f;
	}

	static int GetSubMeshCount(Renderer renderer)
	{
		if (renderer is SkinnedMeshRenderer skinnedRenderer)
			return skinnedRenderer.sharedMesh != null ? skinnedRenderer.sharedMesh.subMeshCount : 0;

		if (renderer is MeshRenderer meshRenderer &&
			meshRenderer.TryGetComponent(out MeshFilter meshFilter) && meshFilter.sharedMesh != null)
			return meshFilter.sharedMesh.subMeshCount;

		return renderer.sharedMaterials.Length;
	}

	readonly struct OutlineDrawRequest
	{
		public readonly Renderer renderer;
		public readonly Material material;
		public readonly int subMeshIndex;

		public OutlineDrawRequest(Renderer renderer, Material material, int subMeshIndex)
		{
			this.renderer = renderer;
			this.material = material;
			this.subMeshIndex = subMeshIndex;
		}
	}
}

public static class UEisBetterOutlineBootstrap
{
	static UEisBetterOutlinePass outlinePass;
	static bool sceneEventsRegistered;

	[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
	public static void EnsureRegistered()
	{
		RegisterSceneEvents();
		if (outlinePass != null)
			return;

		outlinePass = new UEisBetterOutlinePass {
			name = "EpicShade Material Outlines",
			targetColorBuffer = CustomPass.TargetBuffer.Camera,
			targetDepthBuffer = CustomPass.TargetBuffer.Camera,
			clearFlags = ClearFlag.None
		};

		if (!CustomPassVolume.RegisterUniqueGlobalCustomPass(
			CustomPassInjectionPoint.BeforePostProcess,
			outlinePass))
			outlinePass = null;
	}

	public static void Unregister()
	{
		UnregisterSceneEvents();
		if (outlinePass == null)
			return;
		CustomPassVolume.UnregisterGlobalCustomPass(outlinePass);
		outlinePass = null;
	}

	static void RegisterSceneEvents()
	{
		if (sceneEventsRegistered)
			return;
		SceneManager.sceneLoaded += OnSceneLoaded;
		SceneManager.sceneUnloaded += OnSceneUnloaded;
		SceneManager.activeSceneChanged += OnActiveSceneChanged;
		sceneEventsRegistered = true;
	}

	static void UnregisterSceneEvents()
	{
		if (!sceneEventsRegistered)
			return;
		SceneManager.sceneLoaded -= OnSceneLoaded;
		SceneManager.sceneUnloaded -= OnSceneUnloaded;
		SceneManager.activeSceneChanged -= OnActiveSceneChanged;
		sceneEventsRegistered = false;
	}

	static void OnSceneLoaded(Scene scene, LoadSceneMode mode) => UEisBetterOutlinePass.InvalidateRendererCache();
	static void OnSceneUnloaded(Scene scene) => UEisBetterOutlinePass.InvalidateRendererCache();
	static void OnActiveSceneChanged(Scene previous, Scene next) => UEisBetterOutlinePass.InvalidateRendererCache();
}
#endif
