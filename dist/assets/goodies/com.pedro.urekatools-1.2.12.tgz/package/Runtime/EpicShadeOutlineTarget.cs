#if UNITY_PIPELINE_HDRP
using UnityEngine;

/// <summary>
/// Invalidates EpicShade's outline renderer cache when a renderer is spawned,
/// enabled, disabled, or destroyed at runtime. Add this to dynamically spawned
/// objects that use an outlined EpicShade material.
/// </summary>
[DisallowMultipleComponent]
[RequireComponent(typeof(Renderer))]
public sealed class EpicShadeOutlineTarget : MonoBehaviour
{
    void OnEnable() => UEisBetterOutlinePass.InvalidateRendererCache();
    void OnDisable() => UEisBetterOutlinePass.InvalidateRendererCache();
    void OnDestroy() => UEisBetterOutlinePass.InvalidateRendererCache();
}
#endif
