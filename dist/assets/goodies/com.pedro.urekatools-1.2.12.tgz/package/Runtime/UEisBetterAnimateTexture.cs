//              EpicShade
// Local derivative of OmniShade PBR for licensed studio use.
// Original work Copyright© 2025 OmniShade.

using System.Collections.Generic;
using UnityEngine;

/// <summary>Animates texture offsets or frame sequences on EpicShade materials.</summary>
[RequireComponent(typeof(Renderer))]
public class UEisBetterAnimateTexture : MonoBehaviour
{
    public enum UEisBetterTexture
    {
        BaseMap,
        ORMMap,
        BumpMap,
        EmissionMap,
        DetailMap,
        Layer1,
        Layer2,
        Layer3,
        BumpMap2,
        HeightColorsTex,
    }

    [System.Serializable]
    public class AnimatedTexture
    {
        public int matIndex;
        public UEisBetterTexture texture;
        public Vector2 speed;

        [Header("Ping Pong")]
        public bool pingPong;
        [Range(0, 100)] public float frequency;

        [Header("Frame Animation")]
        [Range(1, 60)] public int FPS;
        public Texture2D[] frames;

        [HideInInspector] public int textureID;
        [HideInInspector] public int textureSTID;
        [HideInInspector] public Vector2 currentUV;
        [HideInInspector] public int currentFrame;
        [HideInInspector] public float currentFrameTime;
    }

    public List<AnimatedTexture> texturesToAnimate;

    private Renderer _renderer;
    private Material[] _sharedMaterials;
    private MaterialPropertyBlock[] _propertyBlocks;

    void Start()
    {
        if (texturesToAnimate == null)
            return;

        _renderer = GetComponent<Renderer>();
        _sharedMaterials = _renderer.sharedMaterials;
        _propertyBlocks = new MaterialPropertyBlock[_sharedMaterials.Length];

        for (var i = 0; i < _propertyBlocks.Length; i++)
            _propertyBlocks[i] = new MaterialPropertyBlock();

        foreach (var animatedTexture in texturesToAnimate)
        {
            if (animatedTexture.matIndex < 0 || animatedTexture.matIndex >= _sharedMaterials.Length)
            {
                animatedTexture.textureID = -1;
                Debug.LogError($"Invalid EpicShade material index {animatedTexture.matIndex}.", this);
                continue;
            }

            var material = _sharedMaterials[animatedTexture.matIndex];
            if (material == null)
            {
                animatedTexture.textureID = -1;
                continue;
            }

            animatedTexture.textureID = Shader.PropertyToID("_" + animatedTexture.texture);
            animatedTexture.textureSTID = Shader.PropertyToID("_" + animatedTexture.texture + "_ST");
            animatedTexture.currentUV = material.GetTextureOffset(animatedTexture.textureID);
        }
    }

    void Update()
    {
        if (texturesToAnimate == null || _sharedMaterials == null)
            return;

        foreach (var animatedTexture in texturesToAnimate)
        {
            if (animatedTexture.textureID == -1)
                continue;

            var material = _sharedMaterials[animatedTexture.matIndex];
            if (material == null)
                continue;

            var propertyBlock = _propertyBlocks[animatedTexture.matIndex];
            _renderer.GetPropertyBlock(propertyBlock, animatedTexture.matIndex);
            var changed = false;

            if (animatedTexture.speed != Vector2.zero)
            {
                var speed = animatedTexture.speed;
                if (animatedTexture.pingPong)
                    speed *= Mathf.Sin(Time.time * animatedTexture.frequency);

                animatedTexture.currentUV += speed * Time.deltaTime;
                animatedTexture.currentUV.x %= 1f;
                animatedTexture.currentUV.y %= 1f;

                var scale = material.GetTextureScale(animatedTexture.textureID);
                propertyBlock.SetVector(
                    animatedTexture.textureSTID,
                    new Vector4(scale.x, scale.y, animatedTexture.currentUV.x, animatedTexture.currentUV.y));
                changed = true;
            }

            if (animatedTexture.frames != null && animatedTexture.frames.Length > 0 && animatedTexture.FPS > 0)
            {
                var timePerFrame = 1f / animatedTexture.FPS;
                animatedTexture.currentFrameTime += Time.deltaTime;
                var frameIncrement = (int)(animatedTexture.currentFrameTime / timePerFrame);
                if (frameIncrement > 0)
                {
                    animatedTexture.currentFrame =
                        (animatedTexture.currentFrame + frameIncrement) % animatedTexture.frames.Length;
                    animatedTexture.currentFrameTime %= timePerFrame;
                    propertyBlock.SetTexture(
                        animatedTexture.textureID,
                        animatedTexture.frames[animatedTexture.currentFrame]);
                    changed = true;
                }
            }

            if (changed)
                _renderer.SetPropertyBlock(propertyBlock, animatedTexture.matIndex);
        }
    }
}
