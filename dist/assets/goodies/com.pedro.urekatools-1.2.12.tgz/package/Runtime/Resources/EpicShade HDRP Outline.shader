Shader "Hidden/EpicShade/HDRP Outline"
{
    Properties
    {
        [HDR] _UEisBetterOutlineColor("Outline Color", Color) = (1, 1, 1, 1)
        _UEisBetterOutlineWidth("Outline Width", Float) = 0.01
        _UEisBetterOutlineOpacity("Outline Opacity", Range(0, 1)) = 1
        _UEisBetterOutlineBias("Outline Bias", Range(-1, 1)) = 0
        _UEisBetterOutlineContrast("Outline Contrast", Range(0.1, 10)) = 1
        _UEisBetterOutlineExposureCompensation("Outline Exposure Compensation", Float) = 1
        [HideInInspector] _UEisBetterPlantSwayEnabled("Plant Sway Enabled", Float) = 0
        [HideInInspector] Vector1_6c19bc30b5f24c9981a0b4342363bddd("Plant Sway Amount", Float) = 0.15
        [HideInInspector] Vector1_1d1f6529f5744d9ab4b71e074ea7327c("Plant Sway Speed", Float) = 1
        [HideInInspector] Vector1_b16b91113fe247d98d96cb9c268c473d("Plant Sway Base Height", Float) = 0
        [HideInInspector] Vector1_fa9c479eb4544cceae07165a8a72b81b("Plant Sway Phase Variation", Float) = 0.3
        [HideInInspector] Boolean_4da072f3cb7244e0b71bb01fe70a94e0("Plant Sway As Leaf", Float) = 0
        [HideInInspector] _BaseMap("Main Texture", 2D) = "white" {}
        [HideInInspector] _UEisBetterAlphaClipEnabled("Alpha Clip Enabled", Float) = 0
        [HideInInspector] _UEisBetterIgnoreBaseMapAlpha("Ignore Main Texture Alpha", Float) = 0
        [HideInInspector] _UEisBetterBaseColorAlpha("Base Color Alpha", Float) = 1
        [HideInInspector] _UEisBetterAlphaClipThreshold("Alpha Clip Threshold", Range(0, 1)) = 0.5
    }

    HLSLINCLUDE
    #pragma target 4.5
    #pragma only_renderers d3d11 playstation xboxone xboxseries vulkan metal switch switch2
    #pragma multi_compile_instancing
    #pragma multi_compile _ DOTS_INSTANCING_ON

    #include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Common.hlsl"

CBUFFER_START(UnityPerMaterial)
    float4 _UEisBetterOutlineColor;
    float _UEisBetterOutlineWidth;
    float _UEisBetterOutlineOpacity;
    float _UEisBetterOutlineBias;
    float _UEisBetterOutlineContrast;
    float _UEisBetterOutlineExposureCompensation;
    float _UEisBetterPlantSwayEnabled;
    float Vector1_6c19bc30b5f24c9981a0b4342363bddd;
    float Vector1_1d1f6529f5744d9ab4b71e074ea7327c;
    float Vector1_b16b91113fe247d98d96cb9c268c473d;
    float Vector1_fa9c479eb4544cceae07165a8a72b81b;
    float Boolean_4da072f3cb7244e0b71bb01fe70a94e0;
    float4 _BaseMap_ST;
    float _UEisBetterAlphaClipEnabled;
    float _UEisBetterIgnoreBaseMapAlpha;
    float _UEisBetterBaseColorAlpha;
    float _UEisBetterAlphaClipThreshold;
CBUFFER_END

    TEXTURE2D(_BaseMap);
    SAMPLER(sampler_BaseMap);

    void ApplyUEisBetterAlphaClip(float2 uv0)
    {
        if (_UEisBetterAlphaClipEnabled < 0.5 || _UEisBetterIgnoreBaseMapAlpha > 0.5)
            return;

        float2 uv = uv0 * _BaseMap_ST.xy + _BaseMap_ST.zw;
        float alpha = SAMPLE_TEXTURE2D(_BaseMap, sampler_BaseMap, uv).a * _UEisBetterBaseColorAlpha;
        clip(alpha - _UEisBetterAlphaClipThreshold);
    }

    ENDHLSL

    SubShader
    {
        Tags { "RenderPipeline" = "HDRenderPipeline" }

        // Mark the visible pixels occupied by all outlined meshes.
        Pass
        {
            Name "UEisBetterOutlineSilhouetteMask"
            Tags { "LightMode" = "UEisBetterOutlineSilhouetteMask" }

            Blend Off
            ColorMask R
            ZWrite Off
            ZTest Always
            Cull Off

            HLSLPROGRAM
            #define ATTRIBUTES_NEED_TEXCOORD0
            #define VARYINGS_NEED_TEXCOORD0
            #define HAVE_MESH_MODIFICATION
            #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/RenderPass/CustomPass/CustomPassRenderersV2.hlsl"
            #include "Packages/com.pedro.urekatools/Runtime/Shaders/EpicShade Plant Sway.hlsl"

            AttributesMesh ApplyMeshModification(AttributesMesh input, float3 timeParameters)
            {
                input.positionOS = ApplyUEisBetterPlantSway(input.positionOS, timeParameters);
                return input;
            }

            void GetSurfaceAndBuiltinData(
                FragInputs fragInputs,
                float3 viewDirection,
                inout PositionInputs posInput,
                out SurfaceData surfaceData,
                out BuiltinData builtinData)
            {
                ZERO_BUILTIN_INITIALIZE(builtinData);
                ZERO_INITIALIZE(SurfaceData, surfaceData);
                builtinData.opacity = 1.0;
            }

            #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/ShaderPass/ShaderPassForwardUnlit.hlsl"

            void UEisBetterMaskFrag(PackedVaryingsToPS packedInput, out float4 outColor : SV_Target0)
            {
                UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(packedInput);
                FragInputs input = UnpackVaryingsToFragInputs(packedInput);
                ApplyUEisBetterAlphaClip(input.texCoord0.xy);
                outColor = 1.0;
            }

            #pragma vertex Vert
            #pragma fragment UEisBetterMaskFrag
            ENDHLSL
        }

        // Draw the inverted hull only where the combined silhouette is absent.
        Pass
        {
            Name "UEisBetterOutline"
            Tags { "LightMode" = "UEisBetterOutline" }

            Blend SrcAlpha OneMinusSrcAlpha
            ZWrite Off
            ZTest LEqual
            Cull Front
            HLSLPROGRAM

            #define ATTRIBUTES_NEED_NORMAL
            #define ATTRIBUTES_NEED_TEXCOORD0
            #define VARYINGS_NEED_TEXCOORD0
            #define HAVE_MESH_MODIFICATION

            #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/RenderPass/CustomPass/CustomPassRenderersV2.hlsl"
            #include "Packages/com.pedro.urekatools/Runtime/Shaders/EpicShade Plant Sway.hlsl"

            AttributesMesh ApplyMeshModification(AttributesMesh input, float3 timeParameters)
            {
                input.positionOS = ApplyUEisBetterPlantSway(input.positionOS, timeParameters);
                float3 positionWS = TransformObjectToWorld(input.positionOS);
                float3 normalWS = TransformObjectToWorldNormal(input.normalOS);
                float biasedWidth = max(0.0, _UEisBetterOutlineWidth * (1.0 + _UEisBetterOutlineBias));
                positionWS += normalize(normalWS) * biasedWidth;
                input.positionOS = TransformWorldToObject(positionWS);
                return input;
            }

            void GetSurfaceAndBuiltinData(
                FragInputs fragInputs,
                float3 viewDirection,
                inout PositionInputs posInput,
                out SurfaceData surfaceData,
                out BuiltinData builtinData)
            {
                ZERO_BUILTIN_INITIALIZE(builtinData);
                ZERO_INITIALIZE(SurfaceData, surfaceData);

                float inverseExposure = GetInverseCurrentExposureMultiplier();
                float compensation = saturate(_UEisBetterOutlineExposureCompensation);
                builtinData.opacity = _UEisBetterOutlineColor.a * saturate(_UEisBetterOutlineOpacity);
                builtinData.emissiveColor = _UEisBetterOutlineColor.rgb * max(0.0, _UEisBetterOutlineContrast) *
                    lerp(1.0, inverseExposure, compensation);
                surfaceData.color = 0.0;
            }

            #include "Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/ShaderPass/ShaderPassForwardUnlit.hlsl"

            TEXTURE2D_X(_UEisBetterOutlineMaskTexture);

            void UEisBetterOutlineFrag(PackedVaryingsToPS packedInput, out float4 outColor : SV_Target0)
            {
                UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(packedInput);
                FragInputs input = UnpackVaryingsToFragInputs(packedInput);
                ApplyUEisBetterAlphaClip(input.texCoord0.xy);
                float silhouetteMask = LOAD_TEXTURE2D_X(
					_UEisBetterOutlineMaskTexture,
					uint2(input.positionSS.xy)).r;
                clip(0.5 - silhouetteMask);

                float compensation = saturate(_UEisBetterOutlineExposureCompensation);
                float3 color = _UEisBetterOutlineColor.rgb * max(0.0, _UEisBetterOutlineContrast);
                color *= lerp(GetCurrentExposureMultiplier(), 1.0, compensation);
                float opacity = _UEisBetterOutlineColor.a * saturate(_UEisBetterOutlineOpacity);
                outColor = float4(color, opacity);
            }

            #pragma vertex Vert
            #pragma fragment UEisBetterOutlineFrag
            ENDHLSL
        }

    }
}
