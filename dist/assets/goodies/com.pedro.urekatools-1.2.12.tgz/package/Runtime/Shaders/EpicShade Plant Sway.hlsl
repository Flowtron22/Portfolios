#ifndef TSSHADE_PLANT_SWAY_INCLUDED
#define TSSHADE_PLANT_SWAY_INCLUDED

// Matches the deformation in EpicShade's Plant Sway subgraph. The calculation
// intentionally uses the matrix 3x3 for the height mask, just like the graph,
// so object translation affects phase but not the configured base height.
float3 ApplyUEisBetterPlantSway(float3 positionOS, float3 timeParameters)
{
    if (_UEisBetterPlantSwayEnabled < 0.5)
        return positionOS;

    float3 positionRelativeWS = mul((float3x3)GetObjectToWorldMatrix(), positionOS);
    float3 objectPositionWS = GetObjectToWorldMatrix()._m03_m13_m23;
    float phase = dot(objectPositionWS, float3(1.0, 1.0, 1.0)) *
        Vector1_fa9c479eb4544cceae07165a8a72b81b;
    float timePhase = timeParameters.x * Vector1_1d1f6529f5744d9ab4b71e074ea7327c;
    float heightMask = Boolean_4da072f3cb7244e0b71bb01fe70a94e0 > 0.5
        ? 0.15
        : max(positionRelativeWS.y - Vector1_b16b91113fe247d98d96cb9c268c473d, 0.0);
    float sway = heightMask * Vector1_6c19bc30b5f24c9981a0b4342363bddd;

    float horizontalSway = sin(phase + timePhase) * sway;
    positionRelativeWS.x += horizontalSway;
    positionRelativeWS.z += horizontalSway;
    float verticalWave = sin((phase + timePhase) * 2.0 - 1.570796) * 0.5 + 0.5;
    positionRelativeWS.y -= sway * verticalWave * 0.5;

    return mul((float3x3)GetWorldToObjectMatrix(), positionRelativeWS);
}

#endif
