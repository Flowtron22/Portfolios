# Third Party Notices

EpicShade contains derivative work based on OmniShade PBR. Use and distribution require the appropriate Unity Asset Store license for every person or entity receiving the source assets.
